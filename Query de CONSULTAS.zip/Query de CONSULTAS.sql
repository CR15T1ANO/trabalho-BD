--  utilizando SELECT, WHERE, AND, OR, NOT, ORDER BY, LIMIT, LEFT JOIN, RIGHT JOIN, CROSS JOIN,  UNION:

-- 1  Listar todos os cursos de uma determinada categoria com preço maior que um valor específico e ordenados pelo preço
SELECT c.*
FROM Cursos c
LEFT JOIN Cursos_Categorias cc ON c.curso_id = cc.curso_id
JOIN Categorias cat ON cc.categoria_id = cat.categoria_id
WHERE cat.nome = 'Data Science' AND c.preco > 10
ORDER BY c.preco;
-- 2 Listar todos os usuários que são instrutores ou administradores e que não são administradores
SELECT *
FROM Usuarios
WHERE (tipo = 'Instrutor' OR tipo = 'Administrador') AND NOT tipo = 'Administrador';
-- 3 Listar os 5 cursos mais recentes com avaliações de nota 5
SELECT DISTINCT c.*
FROM Cursos c
RIGHT JOIN Avaliacoes a ON c.curso_id = a.curso_id
WHERE a.nota = 5
ORDER BY c.data_criacao DESC
LIMIT 5;
--  comandos; UPDATE, DELETE:
-- COMANDO UPDATE
    UPDATE Modulos
SET titulo = 'Programação Orientada a Objetos'
WHERE modulo_id = 3;
-- COMANDO DELETE
DELETE FROM Cursos
WHERE preco = 0.00;
INSERT INTO Cursos (titulo, descricao, preco, data_criacao, instrutor_id)
VALUES ('Curso de Programação CSS', 'Aprenda CSS do básico ao avançado.', 0, '2023-01-15', 2);
-- COMANDOS AVG, MAX, COUNT, MIN, SUM
-- 1 Encontrar o curso com a maior média de avaliações
SELECT curso_id, AVG(nota) AS media_avaliacoes
FROM Avaliacoes
GROUP BY curso_id
ORDER BY media_avaliacoes DESC
LIMIT 1;
-- 2 Encontrar a data da última avaliação de cada curso
    SELECT curso_id, MAX(data_avaliacao) AS ultima_avaliacao
FROM Avaliacoes
GROUP BY curso_id;
-- 3 Encontrar o usuário com o maior número de comentários
    SELECT usuario_id, COUNT(*) AS total_comentarios
FROM Comentarios
GROUP BY usuario_id
ORDER BY total_comentarios DESC
LIMIT 1;
-- 4  Encontrar a data do primeiro acesso de cada usuário
SELECT usuario_id, MIN(data_acesso) AS primeiro_acesso
FROM Logs_Acesso
GROUP BY usuario_id;
-- 5 Encontrar a soma total dos valores pagos por cada usuário
SELECT m.usuario_id, SUM(p.valor) AS total_pago
FROM Pagamentos p
JOIN Matriculas m ON p.matricula_id = m.matricula_id
GROUP BY m.usuario_id;
-- 6 CROSS JOIN entre Usuarios e Cursos
    SELECT u.usuario_id, u.nome, c.curso_id, c.titulo
FROM Usuarios u
CROSS JOIN Cursos c;
-- 7 SELF JOIN na Tabela Usuarios
    SELECT u1.usuario_id AS usuario1_id, u1.nome AS usuario1_nome,
       u2.usuario_id AS usuario2_id, u2.nome AS usuario2_nome,
       u1.endereco
FROM Usuarios u1
 LEFT JOIN Usuarios u2 ON u1.endereco = u2.endereco AND u1.usuario_id < u2.usuario_id;
--  UNION
-- 8 Executando a consulta UNION
SELECT usuario_id, nome, email, 'Instrutor' AS tipo
FROM Usuarios
WHERE tipo = 'Instrutor'
UNION
SELECT usuario_id, nome, email, 'Administrador' AS tipo
FROM Usuarios
WHERE tipo = 'Administrador';
--  HAVING
-- Listar instrutores que têm mais de 2 cursos cadastrados
SELECT
    u.usuario_id,
    u.nome,
    COUNT(c.curso_id) AS total_cursos
FROM
    Usuarios u
JOIN
    Cursos c ON u.usuario_id = c.instrutor_id
WHERE
    u.tipo = 'Instrutor'
GROUP BY
    u.usuario_id, u.nome
HAVING
    COUNT(c.curso_id) >= 3;

-- Utilização de LIKE, Wildcards, IN, BETWEEN
-- 1 Encontrar usuários cujos nomes começam com uma determinada letra A
SELECT *
FROM Usuarios
WHERE nome LIKE 'A%';
-- 2 Encontrar cursos que pertencem a determinadas categorias usando IN
SELECT c.*
FROM Cursos c
JOIN Cursos_Categorias cc ON c.curso_id = cc.curso_id
JOIN Categorias cat ON cc.categoria_id = cat.categoria_id
WHERE cat.nome IN ('Programação', 'Design');

-- COMANDOS EXISTS, ANY, ALL:
--  1 Listar os usuários que fizeram pagamentos com valores maiores do que qualquer pagamento realizado em um período específico
SELECT *
FROM Usuarios u
WHERE EXISTS (
    SELECT 1
    FROM Pagamentos p
    WHERE p.pagamento_id = u.usuario_id
    AND p.valor > ANY (
        SELECT valor
        FROM Pagamentos
        WHERE data_pagamento BETWEEN '2023-01-01' AND '2023-12-31'
    )
);
-- 2 Listar os módulos que têm avaliações com nota maior do que todas as avaliações de um curso específico
SELECT *
FROM Modulos m
WHERE EXISTS (
    SELECT 1
    FROM Avaliacoes_Modulos am
    WHERE am.modulo_id = m.modulo_id
    AND am.nota > ALL (
        SELECT nota
        FROM Avaliacoes
        WHERE curso_id = 2
    )
);
-- COMANDOS CASE,IFNULL, COALESCE
-- Selecionando cursos e adicionando uma coluna indicando se o curso é gratuito ou pago
SELECT
    curso_id,
    titulo,
    IFNULL(preco, 0) AS preco, -- Tratando valores nulos na coluna preco
    CASE
        WHEN IFNULL(preco, 0) = 0 THEN 'Gratuito'
        ELSE 'Pago'
    END AS tipo_curso
FROM Cursos;
-- Selecionando usuários e substituindo valores nulos no campo endereco por 'Endereço não informado'
SELECT
    usuario_id,
    nome,
    email,
    COALESCE(endereco, 'Endereço não informado') AS endereco
FROM Usuarios;
-- ALTER TABLE
    ALTER TABLE Cursos
MODIFY COLUMN preco DECIMAL(10, 2) NULL;

UPDATE Cursos
SET preco = NULL
WHERE curso_id = 2;

-- TABELA TESTE
-- Criando uma tabela para armazenar usuários que nunca fizeram pagamento
CREATE TABLE Usuarios_Sem_Pagamento (
    usuario_id INT PRIMARY KEY,
    nome VARCHAR(100),
    email VARCHAR(100),
    data_nascimento DATE
);
DROP TABLE Usuarios_Sem_Pagamento;
-- INDEX
-- Índice para as colunas aula_id e usuario_id (para buscas rápidas por aula e usuário):
CREATE INDEX idx_aulas_assistidas_aula_usuario ON Aulas_Assistidas(aula_id, usuario_id);
-- SELECT INDEX
SELECT *
FROM Aulas_Assistidas
WHERE aula_id = 1 AND usuario_id = 1;
-- VIEWS
-- Criação da Visão para Listar Todas as Matrículas do Mês Atual
CREATE VIEW Matriculas_Mes_Atual AS
SELECT *
FROM Matriculas
WHERE YEAR(data_matricula) = YEAR(CURRENT_DATE())
  AND MONTH(data_matricula) = MONTH(CURRENT_DATE());
-- SELECT DA VIEWS
SELECT *
FROM Matriculas_Mes_Atual;



