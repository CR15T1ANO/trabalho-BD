use ensinoonlinedb;


create table Logs_Acesso
(
   ID        int auto_increment primary key,
   DESCRICAO VARCHAR(100)
);
INSERT INTO Logs_Acesso (DESCRICAO)  VALUES ('DELETE'), ('INSERT'), ('UPDATE DADOS ANTIGOS'), ('UPDATE DADOS NOVOS');
-- =========================================================


-- Log USUARIOS
CREATE TABLE log_usuarios
(
   log_usuarios_id INT AUTO_INCREMENT PRIMARY KEY,
   nome varchar(100),
   email  varchar(100),
   senha varchar(100),
   data_nascimento date,
   endereco varchar(255),
   telefone varchar(20),
   tipo enum('Aluno','Instrutor','Adminstrador'),
   operacao       INT
);


-- INSERT
CREATE TRIGGER insert_usuarios
   AFTER INSERT ON usuarios
   FOR EACH ROW
BEGIN
   INSERT INTO log_usuarios (nome, email, senha, data_nascimento, endereco, telefone, tipo, operacao)
   VALUES (NEW.nome, NEW.email, NEW.senha, NEW.data_nascimento, NEW.endereco, NEW.telefone, NEW.tipo, 2);
END;


-- DELETE
CREATE TRIGGER delete_usuarios
   BEFORE DELETE ON usuarios
   FOR EACH ROW
BEGIN
   INSERT INTO log_usuarios (nome, email, senha, data_nascimento, endereco, telefone, tipo, operacao)
   VALUES (OLD.nome, OLD.email, OLD.senha, OLD.data_nascimento, OLD.endereco, OLD.telefone, OLD.tipo, 1);
END;


-- UPDATE
CREATE TRIGGER update_usuarios
   AFTER UPDATE ON usuarios
   FOR EACH ROW
BEGIN
   INSERT INTO log_usuarios (nome, email, senha, data_nascimento, endereco, telefone, tipo, operacao)
   VALUES (OLD.nome, OLD.email, OLD.senha, OLD.data_nascimento, OLD.endereco, OLD.telefone, OLD.tipo, 3);
   INSERT INTO log_usuarios (nome, email, senha, data_nascimento, endereco, telefone, tipo, operacao)
   VALUES (NEW.nome, NEW.email, NEW.senha, NEW.data_nascimento, NEW.endereco, NEW.telefone, NEW.tipo,  4);
END;
-- =============================================================
-- Log CURSOS
CREATE TABLE log_cursos
(
   log_cursos_id INT AUTO_INCREMENT PRIMARY KEY,
   titulo varchar(200),
   descricao  text,
   preco decimal(10,2),
   data_criacao date,
   instrutor_id int,
   operacao       INT
);


-- INSERT
CREATE TRIGGER insert_cursos
   AFTER INSERT ON cursos
   FOR EACH ROW
BEGIN
   INSERT INTO log_cursos (titulo, descricao, preco, data_criacao, instrutor_id, operacao)
   VALUES (NEW.titulo, NEW.descricao, NEW.preco, NEW.data_criacao, NEW.instrutor_id, 2);
END;


-- DELETE
CREATE TRIGGER delete_cursos
   BEFORE DELETE ON cursos
   FOR EACH ROW
BEGIN
   INSERT INTO log_cursos (titulo, descricao, preco, data_criacao, instrutor_id, operacao)
   VALUES (OLD.titulo, OLD.descricao, OLD.preco, OLD.data_criacao, OLD.instrutor_id, 1);
END;


-- UPDATE
CREATE TRIGGER update_cursos
   AFTER UPDATE ON cursos
   FOR EACH ROW
BEGIN
   INSERT INTO log_cursos (titulo, descricao, preco, data_criacao, instrutor_id, operacao)
   VALUES (OLD.titulo, OLD.descricao, OLD.preco, OLD.data_criacao, OLD.instrutor_id, 3);
   INSERT INTO log_cursos (titulo, descricao, preco, data_criacao, instrutor_id, operacao)
   VALUES (NEW.titulo, NEW.descricao, NEW.preco, NEW.data_criacao, NEW.instrutor_id,  4);
END;
-- ============================================
-- Log PAGAMENTOS
CREATE TABLE log_pagamentos
(
   log_pagamentos_id INT AUTO_INCREMENT PRIMARY KEY,
   matricula_id int,
   data_pagamento date,
   valor decimal(10,2),
   metodo_pagamento varchar(50),
   operacao       INT
);


-- INSERT
CREATE TRIGGER insert_pagamentos
   AFTER INSERT ON pagamentos
   FOR EACH ROW
BEGIN
   INSERT INTO log_pagamentos (matricula_id, data_pagamento, valor, metodo_pagamento, operacao)
   VALUES (NEW.matricula_id, NEW.data_pagamento, NEW.valor, NEW.metodo_pagamento, 2);
END;


-- DELETE
CREATE TRIGGER delete_pagamentos
   BEFORE DELETE ON pagamentos
   FOR EACH ROW
BEGIN
   INSERT INTO log_pagamentos (matricula_id, data_pagamento, valor, metodo_pagamento, operacao)
   VALUES (OLD.matricula_id, OLD.data_pagamento, OLD.valor, OLD.metodo_pagamento, 1);
END;


-- UPDATE
CREATE TRIGGER update_pagamentos
   AFTER UPDATE ON pagamentos
   FOR EACH ROW
BEGIN
   INSERT INTO log_pagamentos (matricula_id, data_pagamento, valor, metodo_pagamento, operacao)
   VALUES (OLD.matricula_id, OLD.data_pagamento, OLD.valor, OLD.metodo_pagamento, 3);
   INSERT INTO log_pagamentos (matricula_id, data_pagamento, valor, metodo_pagamento, operacao)
   VALUES (NEW.matricula_id, NEW.data_pagamento, NEW.valor, NEW.metodo_pagamento,  4);
END;
-- =========================================================
-- Log MATRICULA
CREATE TABLE log_matriculas
(
   log_matriculas_id INT AUTO_INCREMENT PRIMARY KEY,
   usuario_id int,
   curso_id int,
   data_matricula date,
   operacao       INT
);


-- INSERT
CREATE TRIGGER insert_matriculas
   AFTER INSERT ON matriculas
   FOR EACH ROW
BEGIN
   INSERT INTO log_matriculas(usuario_id, curso_id, data_matricula, operacao)
   VALUES (NEW.usuario_id, NEW.curso_id, NEW.data_matricula, 2);
END;


-- DELETE
CREATE TRIGGER delete_matriculas
   BEFORE DELETE ON matriculas
   FOR EACH ROW
BEGIN
   INSERT INTO log_matriculas (usuario_id, curso_id, data_matricula, operacao)
   VALUES (OLD.usuario_id, OLD.curso_id, OLD.data_matricula, 1);
END;


-- UPDATE
CREATE TRIGGER update_matriculas
   AFTER UPDATE ON matriculas
   FOR EACH ROW
BEGIN
   INSERT INTO log_matriculas (usuario_id, curso_id, data_matricula, operacao)
   VALUES (OLD.usuario_id, OLD.curso_id, OLD.data_matricula, 3);
   INSERT INTO log_matriculas (usuario_id, curso_id, data_matricula, operacao)
   VALUES (NEW.usuario_id, NEW.curso_id, NEW.data_matricula,  4);
END;
-- ========================================================


-- Log CERTIFICADOS
CREATE TABLE log_certificados
(
   log_certificados_id INT AUTO_INCREMENT PRIMARY KEY,
   certificado_id int,
   matricula_id int,
   data_emissao date,
   codigo_validacao varchar(100),
   operacao int
);




-- INSERT
CREATE TRIGGER insert_certificados
   AFTER INSERT ON certificados
   FOR EACH ROW
BEGIN
   INSERT INTO log_certificados(certificado_id, matricula_id, data_emissao, codigo_validacao, operacao)
   VALUES (NEW.certificado_id, NEW.matricula_id, NEW.data_emissao, new.codigo_validacao, 2);
END;




-- DELETE
CREATE TRIGGER delete_certificados
   BEFORE DELETE ON certificados
   FOR EACH ROW
BEGIN
   INSERT INTO log_certificados (certificado_id, matricula_id, data_emissao, codigo_validacao, operacao)
   VALUES (OLD.certificado_id, OLD.matricula_id, OLD.data_emissao, OLD.codigo_validacao, 1);
END;




-- UPDATE
CREATE TRIGGER update_certificados
   AFTER UPDATE ON certificados
   FOR EACH ROW
BEGIN
   INSERT INTO log_certificados (certificado_id, matricula_id, data_emissao, codigo_validacao, operacao)
   VALUES (OLD.certificado_id, OLD.matricula_id, OLD.data_emissao, OLD.codigo_validacao, 3);
   INSERT INTO log_certificados (certificado_id, matricula_id, data_emissao, codigo_validacao, operacao)
   VALUES (NEW.certificado_id, NEW.matricula_id, NEW.data_emissao, new.codigo_validacao,   4);
END;
-- ========================================================




INSERT INTO matriculas (usuario_id, curso_id, data_matricula )
VALUES (1, 1, '1987-10-10');




UPDATE matriculas
SET data_matricula = '1987-10-15'
WHERE matricula_id = 26;




DELETE FROM matriculas
WHERE matricula_id = 26;





