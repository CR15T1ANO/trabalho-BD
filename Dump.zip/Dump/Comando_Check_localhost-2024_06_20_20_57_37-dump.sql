-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ensinoonlinedb
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `anuncios`
--

DROP TABLE IF EXISTS `anuncios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `anuncios` (
  `anuncio_id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(200) NOT NULL,
  `descricao` text,
  `data_publicacao` date NOT NULL,
  `usuario_id` int DEFAULT NULL,
  PRIMARY KEY (`anuncio_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `anuncios_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anuncios`
--

LOCK TABLES `anuncios` WRITE;
/*!40000 ALTER TABLE `anuncios` DISABLE KEYS */;
INSERT INTO `anuncios` VALUES (1,'Novo Curso de Java','Aprenda Java do zero ao avançado.','2023-01-10',1),(2,'Data Science para Iniciantes','Curso completo de Data Science.','2023-02-15',2),(3,'Web Design Básico','Curso de introdução ao Web Design.','2023-03-20',3),(4,'Marketing Digital Avançado','Domine o Marketing Digital.','2023-04-25',4),(5,'Fotografia Profissional','Curso para se tornar um fotógrafo profissional.','2023-05-30',5),(6,'Desenvolvimento Mobile com Flutter','Aprenda a criar apps com Flutter.','2023-06-10',6),(7,'Inteligência Artificial na Prática','Curso prático de IA.','2023-07-15',7),(8,'E-commerce de Sucesso','Crie sua loja virtual e venda mais.','2023-08-20',8),(9,'Curso Completo de Python','Aprenda Python do básico ao avançado.','2023-09-25',9),(10,'SEO para Iniciantes','Otimização de sites para motores de busca.','2023-10-10',10),(11,'Introdução ao Machine Learning','Curso básico de Machine Learning.','2023-11-15',11),(12,'Redes Neurais com Python','Aprenda a criar redes neurais.','2023-12-20',12),(13,'Fotografia para Redes Sociais','Melhore suas fotos para Instagram e Facebook.','2024-01-10',13),(14,'JavaScript Avançado','Domine o JavaScript com este curso avançado.','2024-02-15',14),(15,'Programação em C#','Curso completo de programação em C#.','2024-03-20',15),(16,'Design de Interface','Crie interfaces incríveis.','2024-04-25',16),(17,'Machine Learning com R','Curso completo de ML com R.','2024-05-30',17),(18,'Criação de Sites Responsivos','Aprenda a criar sites que se adaptam a qualquer tela.','2024-06-10',18),(19,'Python para Data Science','Curso de Data Science com Python.','2024-07-15',19),(20,'Introdução ao SEO','Curso básico de SEO.','2024-08-20',20),(21,'Desenvolvimento de Jogos com Unity','Crie jogos incríveis com Unity.','2024-09-25',21),(22,'Análise de Dados com Excel','Aprenda a analisar dados com Excel.','2024-10-10',22),(23,'Curso de WordPress','Crie sites profissionais com WordPress.','2024-11-15',23),(24,'Marketing de Conteúdo','Aprenda a criar conteúdo que vende.','2024-12-20',24),(25,'Desenvolvimento Full Stack','Torne-se um desenvolvedor Full Stack.','2025-01-10',25);
/*!40000 ALTER TABLE `anuncios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aulas`
--

DROP TABLE IF EXISTS `aulas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aulas` (
  `aula_id` int NOT NULL AUTO_INCREMENT,
  `modulo_id` int DEFAULT NULL,
  `titulo` varchar(200) NOT NULL,
  `descricao` text,
  `duracao` time NOT NULL,
  `video_url` varchar(255) DEFAULT NULL,
  `ordem` int NOT NULL,
  PRIMARY KEY (`aula_id`),
  KEY `modulo_id` (`modulo_id`),
  CONSTRAINT `aulas_ibfk_1` FOREIGN KEY (`modulo_id`) REFERENCES `modulos` (`modulo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aulas`
--

LOCK TABLES `aulas` WRITE;
/*!40000 ALTER TABLE `aulas` DISABLE KEYS */;
INSERT INTO `aulas` VALUES (1,1,'Instalação do Java','Como instalar o Java.','00:10:00','https://example.com/video1',1),(2,1,'Primeiro Programa','Criando o primeiro programa em Java.','00:15:00','https://example.com/video2',2),(3,2,'Estruturas Condicionais','Uso de if-else em Java.','00:20:00','https://example.com/video3',1),(4,2,'Estruturas de Repetição','Uso de loops em Java.','00:25:00','https://example.com/video4',2),(5,3,'Classes e Objetos','Definindo classes e objetos em Java.','00:30:00','https://example.com/video5',1),(6,3,'Herança e Polimorfismo','Conceitos de herança e polimorfismo.','00:35:00','https://example.com/video6',2),(7,4,'ArrayList e HashMap','Trabalhando com ArrayList e HashMap.','00:40:00','https://example.com/video7',1),(8,4,'Set e Queue','Trabalhando com Set e Queue.','00:45:00','https://example.com/video8',2),(9,5,'Streams e Lambda','Uso de streams e expressões lambda.','00:50:00','https://example.com/video9',1),(10,5,'Programação Funcional','Conceitos de programação funcional.','00:55:00','https://example.com/video10',2),(11,6,'Introdução ao Data Science','O que é Data Science.','01:00:00','https://example.com/video11',1),(12,6,'Python para Data Science','Usando Python para Data Science.','01:05:00','https://example.com/video12',2),(13,7,'Estatística Descritiva','Conceitos de estatística descritiva.','01:10:00','https://example.com/video13',1),(14,7,'Distribuições de Probabilidade','Conceitos de distribuições de probabilidade.','01:15:00','https://example.com/video14',2),(15,8,'Pandas para Manipulação de Dados','Uso da biblioteca Pandas.','01:20:00','https://example.com/video15',1),(16,8,'Numpy para Manipulação de Dados','Uso da biblioteca Numpy.','01:25:00','https://example.com/video16',2),(17,9,'Gráficos com Matplotlib','Criação de gráficos com Matplotlib.','01:30:00','https://example.com/video17',1),(18,9,'Gráficos com Seaborn','Criação de gráficos com Seaborn.','01:35:00','https://example.com/video18',2),(19,10,'Regressão Linear','Implementação de regressão linear.','01:40:00','https://example.com/video19',1),(20,10,'Classificação com SVM','Implementação de classificação com SVM.','01:45:00','https://example.com/video20',2),(21,11,'Introdução ao HTML','Estrutura básica do HTML.','01:50:00','https://example.com/video21',1),(22,11,'Tags HTML','Uso de tags HTML.','01:55:00','https://example.com/video22',2),(23,12,'CSS Básico','Conceitos básicos de CSS.','02:00:00','https://example.com/video23',1),(24,12,'Seletores CSS','Uso de seletores CSS.','02:05:00','https://example.com/video24',2);
/*!40000 ALTER TABLE `aulas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aulas_assistidas`
--

DROP TABLE IF EXISTS `aulas_assistidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aulas_assistidas` (
  `aula_assistida_id` int NOT NULL AUTO_INCREMENT,
  `aula_id` int DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  `data_assistencia` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`aula_assistida_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_aulas_assistidas_aula_usuario` (`aula_id`,`usuario_id`),
  CONSTRAINT `aulas_assistidas_ibfk_1` FOREIGN KEY (`aula_id`) REFERENCES `aulas` (`aula_id`),
  CONSTRAINT `aulas_assistidas_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aulas_assistidas`
--

LOCK TABLES `aulas_assistidas` WRITE;
/*!40000 ALTER TABLE `aulas_assistidas` DISABLE KEYS */;
INSERT INTO `aulas_assistidas` VALUES (1,1,1,'2024-05-20 22:11:43'),(2,2,1,'2024-05-20 22:11:43'),(3,3,2,'2024-05-20 22:11:43'),(4,4,2,'2024-05-20 22:11:43'),(5,5,3,'2024-05-20 22:11:43'),(6,6,3,'2024-05-20 22:11:43'),(7,7,4,'2024-05-20 22:11:43'),(8,8,4,'2024-05-20 22:11:43'),(9,9,5,'2024-05-20 22:11:43'),(10,10,5,'2024-05-20 22:11:43'),(11,11,6,'2024-05-20 22:11:43'),(12,12,6,'2024-05-20 22:11:43'),(13,13,7,'2024-05-20 22:11:43'),(14,14,7,'2024-05-20 22:11:43'),(15,15,8,'2024-05-20 22:11:43'),(16,16,8,'2024-05-20 22:11:43'),(17,17,9,'2024-05-20 22:11:43'),(18,18,9,'2024-05-20 22:11:43'),(19,19,10,'2024-05-20 22:11:43'),(20,20,10,'2024-05-20 22:11:43'),(21,21,11,'2024-05-20 22:11:43'),(22,22,11,'2024-05-20 22:11:43'),(23,23,12,'2024-05-20 22:11:43'),(24,24,12,'2024-05-20 22:11:43');
/*!40000 ALTER TABLE `aulas_assistidas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avaliacoes`
--

DROP TABLE IF EXISTS `avaliacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avaliacoes` (
  `avaliacao_id` int NOT NULL AUTO_INCREMENT,
  `curso_id` int DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  `nota` int DEFAULT NULL,
  `comentario` text,
  `data_avaliacao` date DEFAULT NULL,
  PRIMARY KEY (`avaliacao_id`),
  KEY `curso_id` (`curso_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `avaliacoes_ibfk_1` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`curso_id`),
  CONSTRAINT `avaliacoes_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`),
  CONSTRAINT `avaliacoes_chk_1` CHECK ((`nota` between 1 and 5))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avaliacoes`
--

LOCK TABLES `avaliacoes` WRITE;
/*!40000 ALTER TABLE `avaliacoes` DISABLE KEYS */;
INSERT INTO `avaliacoes` VALUES (1,1,1,5,'Excelente curso!','2023-01-25'),(2,2,1,4,'Muito bom!','2023-02-28'),(3,3,2,3,'Bom, mas poderia ser melhor.','2023-03-20'),(4,4,2,5,'Curso incrível!','2023-05-05'),(5,5,3,2,'Não gostei muito.','2023-06-01'),(6,6,3,4,'Conteúdo bem explicado.','2023-07-01'),(7,7,4,5,'Excelente!','2023-08-10'),(8,8,4,3,'Esperava mais.','2023-09-01'),(9,9,5,4,'Muito bom curso.','2023-10-01'),(10,10,5,5,'Recomendo!','2023-11-01'),(11,11,6,3,'Bom curso.','2023-12-01'),(12,12,6,4,'Gostei.','2024-01-01'),(13,13,7,2,'Poderia ser melhor.','2024-02-01'),(14,14,7,5,'Adorei!','2024-03-01'),(15,15,8,4,'Muito interessante.','2024-04-01'),(16,16,8,5,'Excelente conteúdo.','2024-05-01'),(17,17,9,3,'Foi bom.','2024-06-01'),(18,18,9,4,'Gostei muito.','2024-07-01'),(19,19,10,5,'Perfeito!','2024-08-01'),(20,20,10,3,'Esperava mais.','2024-09-01'),(21,21,11,4,'Bom curso.','2024-10-01'),(22,22,11,5,'Recomendo!','2024-11-01'),(23,23,12,2,'Não gostei muito.','2024-12-01'),(24,24,12,4,'Conteúdo bem explicado.','2025-01-01'),(25,25,13,5,'Excelente!','2025-02-01');
/*!40000 ALTER TABLE `avaliacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avaliacoes_modulos`
--

DROP TABLE IF EXISTS `avaliacoes_modulos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avaliacoes_modulos` (
  `avaliacao_modulo_id` int NOT NULL AUTO_INCREMENT,
  `modulo_id` int DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  `nota` int DEFAULT NULL,
  `comentario` text,
  `data_avaliacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`avaliacao_modulo_id`),
  KEY `modulo_id` (`modulo_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `avaliacoes_modulos_ibfk_1` FOREIGN KEY (`modulo_id`) REFERENCES `modulos` (`modulo_id`),
  CONSTRAINT `avaliacoes_modulos_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`),
  CONSTRAINT `avaliacoes_modulos_chk_1` CHECK ((`nota` between 1 and 5))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avaliacoes_modulos`
--

LOCK TABLES `avaliacoes_modulos` WRITE;
/*!40000 ALTER TABLE `avaliacoes_modulos` DISABLE KEYS */;
INSERT INTO `avaliacoes_modulos` VALUES (1,1,1,5,'Excelente módulo!','2024-05-20 22:11:43'),(2,2,2,4,'Muito bom, mas poderia ter mais exemplos.','2024-05-20 22:11:43'),(3,3,3,3,'Bom, mas faltou aprofundar em alguns tópicos.','2024-05-20 22:11:43'),(4,4,4,5,'Ótimo conteúdo e didática.','2024-05-20 22:11:43'),(5,5,5,4,'Gostei bastante, mas poderia ter mais exercícios práticos.','2024-05-20 22:11:43'),(6,6,6,5,'Muito bem explicado.','2024-05-20 22:11:43'),(7,7,7,3,'Achei um pouco superficial.','2024-05-20 22:11:43'),(8,8,8,5,'Perfeito, muito detalhado.','2024-05-20 22:11:43'),(9,9,9,4,'Bom, mas senti falta de alguns detalhes.','2024-05-20 22:11:43'),(10,10,10,5,'Excelente, muito prático.','2024-05-20 22:11:43'),(11,11,11,3,'Conteúdo interessante, mas poderia ser mais claro.','2024-05-20 22:11:43'),(12,12,12,5,'Muito bom, aprendi bastante.','2024-05-20 22:11:43'),(13,13,13,4,'Gostei, mas poderia ter mais exemplos.','2024-05-20 22:11:43'),(14,14,14,5,'Excelente, recomendo.','2024-05-20 22:11:43'),(15,15,15,3,'Bom, mas achei um pouco confuso.','2024-05-20 22:11:43'),(16,16,16,4,'Muito bom, mas poderia ser mais detalhado.','2024-05-20 22:11:43'),(17,17,17,5,'Ótimo, muito prático.','2024-05-20 22:11:43'),(18,18,18,4,'Gostei, mas faltaram exemplos práticos.','2024-05-20 22:11:43'),(19,19,19,5,'Excelente, muito bem explicado.','2024-05-20 22:11:43'),(20,20,20,3,'Achei um pouco difícil de entender.','2024-05-20 22:11:43'),(21,21,21,4,'Bom, mas poderia ser mais claro.','2024-05-20 22:11:43'),(22,22,22,5,'Excelente, muito didático.','2024-05-20 22:11:43'),(23,23,23,4,'Gostei, mas faltaram exemplos.','2024-05-20 22:11:43'),(24,24,24,5,'Ótimo conteúdo.','2024-05-20 22:11:43'),(25,25,25,3,'Bom, mas achei um pouco superficial.','2024-05-20 22:11:43');
/*!40000 ALTER TABLE `avaliacoes_modulos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias` (
  `categoria_id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `descricao` text,
  PRIMARY KEY (`categoria_id`),
  UNIQUE KEY `nome` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'Programação','Cursos de programação.'),(2,'Data Science','Cursos de ciência de dados.'),(3,'Desenvolvimento Web','Cursos de desenvolvimento web.'),(4,'Machine Learning','Cursos de aprendizado de máquina.'),(5,'Marketing Digital','Cursos de marketing digital.'),(6,'Design','Cursos de design.'),(7,'Fotografia','Cursos de fotografia.'),(8,'Desenvolvimento Mobile','Cursos de desenvolvimento mobile.'),(9,'Inteligência Artificial','Cursos de inteligência artificial.'),(10,'E-commerce','Cursos de comércio eletrônico.'),(11,'Desenvolvimento WebSite','Cursos relacionados ao desenvolvimento de sites e aplicações web.'),(12,'Análise de Dados','Cursos sobre análise de dados, machine learning e inteligência artificial.'),(13,'Estratégias de Marketing','Cursos sobre estratégias de marketing online e social media.'),(14,'Design Gráfico','Cursos sobre design, criação e edição de imagens e vídeos.'),(15,'Finanças','Cursos sobre gestão financeira, investimentos e economia.'),(16,'Fotografia Avançada','Cursos sobre técnicas fotográficas avançadas e edição de imagens.'),(17,'Música','Cursos sobre teoria musical, instrumentos e produção musical.'),(18,'Línguas','Cursos para aprender diferentes idiomas.'),(19,'Escrita Criativa','Cursos sobre técnicas de escrita e produção de conteúdo.'),(20,'Gestão de Projetos','Cursos sobre metodologias e práticas de gestão de projetos.'),(21,'Treinamento Pessoal','Cursos sobre desenvolvimento pessoal e profissional.'),(22,'Educação Infantil','Cursos sobre técnicas e práticas para educação infantil.'),(23,'Comércio Eletrônico','Cursos sobre criação e gestão de lojas virtuais.'),(24,'Habilidades Interpessoais','Cursos sobre comunicação, liderança e trabalho em equipe.'),(25,'Coaching','Cursos sobre técnicas de coaching e desenvolvimento de habilidades.');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificados`
--

DROP TABLE IF EXISTS `certificados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificados` (
  `certificado_id` int NOT NULL AUTO_INCREMENT,
  `matricula_id` int DEFAULT NULL,
  `data_emissao` date NOT NULL,
  `codigo_validacao` varchar(100) NOT NULL,
  PRIMARY KEY (`certificado_id`),
  UNIQUE KEY `codigo_validacao` (`codigo_validacao`),
  KEY `matricula_id` (`matricula_id`),
  CONSTRAINT `certificados_ibfk_1` FOREIGN KEY (`matricula_id`) REFERENCES `matriculas` (`matricula_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificados`
--

LOCK TABLES `certificados` WRITE;
/*!40000 ALTER TABLE `certificados` DISABLE KEYS */;
INSERT INTO `certificados` VALUES (1,1,'2023-02-01','ABC123DEF'),(2,2,'2023-03-05','GHI456JKL'),(3,3,'2023-04-01','MNO789PQR'),(4,4,'2023-05-15','STU123VWX'),(5,5,'2023-06-05','YZA456BCD'),(6,6,'2023-07-10','EFG789HIJ'),(7,7,'2023-08-01','KLM123NOP'),(8,8,'2023-09-15','QRS456TUV'),(9,9,'2023-10-05','WXY789ZAB'),(10,10,'2023-11-01','CDE123FGH'),(11,11,'2023-12-05','IJK456LMN'),(12,12,'2024-01-10','OPQ789RST'),(13,13,'2024-02-01','UVW123XYZ'),(14,14,'2024-03-05','BCD456EFG'),(15,15,'2024-04-01','HIJ789KLM'),(16,16,'2024-05-15','NOP123QRS'),(17,17,'2024-06-05','TUV456WXY'),(18,18,'2024-07-10','ZAB789CDE'),(19,19,'2024-08-01','FGH123IJK'),(20,20,'2024-09-15','LMN456OPQ'),(21,21,'2024-10-05','RST789UVW'),(22,22,'2024-11-01','XYZ123BCD'),(23,23,'2024-12-05','EFG456HIJ'),(24,24,'2025-01-10','KLM789NOP'),(25,25,'2025-02-01','QRS123TUV');
/*!40000 ALTER TABLE `certificados` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `insert_certificados` AFTER INSERT ON `certificados` FOR EACH ROW BEGIN
    INSERT INTO log_certificados(certificado_id, matricula_id, data_emissao, codigo_validacao, operacao)
    VALUES (NEW.certificado_id, NEW.matricula_id, NEW.data_emissao, new.codigo_validacao, 2);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `update_certificados` AFTER UPDATE ON `certificados` FOR EACH ROW BEGIN
    INSERT INTO log_certificados (certificado_id, matricula_id, data_emissao, codigo_validacao, operacao)
    VALUES (OLD.certificado_id, OLD.matricula_id, OLD.data_emissao, OLD.codigo_validacao, 3);
    INSERT INTO log_certificados (certificado_id, matricula_id, data_emissao, codigo_validacao, operacao)
    VALUES (NEW.certificado_id, NEW.matricula_id, NEW.data_emissao, new.codigo_validacao,   4);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `delete_certificados` BEFORE DELETE ON `certificados` FOR EACH ROW BEGIN
    INSERT INTO log_certificados (certificado_id, matricula_id, data_emissao, codigo_validacao, operacao)
    VALUES (OLD.certificado_id, OLD.matricula_id, OLD.data_emissao, OLD.codigo_validacao, 1);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `certificados_compartilhados`
--

DROP TABLE IF EXISTS `certificados_compartilhados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificados_compartilhados` (
  `compartilhamento_id` int NOT NULL AUTO_INCREMENT,
  `certificado_id` int DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  `plataforma` varchar(100) NOT NULL,
  `data_compartilhamento` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`compartilhamento_id`),
  KEY `certificado_id` (`certificado_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `certificados_compartilhados_ibfk_1` FOREIGN KEY (`certificado_id`) REFERENCES `certificados` (`certificado_id`),
  CONSTRAINT `certificados_compartilhados_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificados_compartilhados`
--

LOCK TABLES `certificados_compartilhados` WRITE;
/*!40000 ALTER TABLE `certificados_compartilhados` DISABLE KEYS */;
INSERT INTO `certificados_compartilhados` VALUES (1,1,1,'LinkedIn','2024-05-20 22:11:43'),(2,2,2,'Facebook','2024-05-20 22:11:43'),(3,3,3,'Twitter','2024-05-20 22:11:43'),(4,4,4,'Instagram','2024-05-20 22:11:43'),(5,5,5,'LinkedIn','2024-05-20 22:11:43'),(6,6,6,'Facebook','2024-05-20 22:11:43'),(7,7,7,'Twitter','2024-05-20 22:11:43'),(8,8,8,'Instagram','2024-05-20 22:11:43'),(9,9,9,'LinkedIn','2024-05-20 22:11:43'),(10,10,10,'Facebook','2024-05-20 22:11:43'),(11,11,11,'Twitter','2024-05-20 22:11:43'),(12,12,12,'Instagram','2024-05-20 22:11:43'),(13,13,13,'LinkedIn','2024-05-20 22:11:43'),(14,14,14,'Facebook','2024-05-20 22:11:43'),(15,15,15,'Twitter','2024-05-20 22:11:43'),(16,16,16,'Instagram','2024-05-20 22:11:43'),(17,17,17,'LinkedIn','2024-05-20 22:11:43'),(18,18,18,'Facebook','2024-05-20 22:11:43'),(19,19,19,'Twitter','2024-05-20 22:11:43'),(20,20,20,'Instagram','2024-05-20 22:11:43'),(21,21,21,'LinkedIn','2024-05-20 22:11:43'),(22,22,22,'Facebook','2024-05-20 22:11:43'),(23,23,23,'Twitter','2024-05-20 22:11:43'),(24,24,24,'Instagram','2024-05-20 22:11:43'),(25,25,25,'LinkedIn','2024-05-20 22:11:43');
/*!40000 ALTER TABLE `certificados_compartilhados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificados_revalidados`
--

DROP TABLE IF EXISTS `certificados_revalidados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificados_revalidados` (
  `revalidacao_id` int NOT NULL AUTO_INCREMENT,
  `certificado_id` int DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  `data_revalidacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`revalidacao_id`),
  KEY `certificado_id` (`certificado_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `certificados_revalidados_ibfk_1` FOREIGN KEY (`certificado_id`) REFERENCES `certificados` (`certificado_id`),
  CONSTRAINT `certificados_revalidados_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificados_revalidados`
--

LOCK TABLES `certificados_revalidados` WRITE;
/*!40000 ALTER TABLE `certificados_revalidados` DISABLE KEYS */;
INSERT INTO `certificados_revalidados` VALUES (1,1,1,'2024-05-20 22:11:43'),(2,2,2,'2024-05-20 22:11:43'),(3,3,3,'2024-05-20 22:11:43'),(4,4,4,'2024-05-20 22:11:43'),(5,5,5,'2024-05-20 22:11:43'),(6,6,6,'2024-05-20 22:11:43'),(7,7,7,'2024-05-20 22:11:43'),(8,8,8,'2024-05-20 22:11:43'),(9,9,9,'2024-05-20 22:11:43'),(10,10,10,'2024-05-20 22:11:43'),(11,11,11,'2024-05-20 22:11:43'),(12,12,12,'2024-05-20 22:11:43'),(13,13,13,'2024-05-20 22:11:43'),(14,14,14,'2024-05-20 22:11:43'),(15,15,15,'2024-05-20 22:11:43'),(16,16,16,'2024-05-20 22:11:43'),(17,17,17,'2024-05-20 22:11:43'),(18,18,18,'2024-05-20 22:11:43'),(19,19,19,'2024-05-20 22:11:43'),(20,20,20,'2024-05-20 22:11:43'),(21,21,21,'2024-05-20 22:11:43'),(22,22,22,'2024-05-20 22:11:43'),(23,23,23,'2024-05-20 22:11:43'),(24,24,24,'2024-05-20 22:11:43'),(25,25,25,'2024-05-20 22:11:43');
/*!40000 ALTER TABLE `certificados_revalidados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comentarios`
--

DROP TABLE IF EXISTS `comentarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comentarios` (
  `comentario_id` int NOT NULL AUTO_INCREMENT,
  `aula_id` int DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  `comentario` text NOT NULL,
  `data_comentario` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`comentario_id`),
  KEY `aula_id` (`aula_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `comentarios_ibfk_1` FOREIGN KEY (`aula_id`) REFERENCES `aulas` (`aula_id`),
  CONSTRAINT `comentarios_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comentarios`
--

LOCK TABLES `comentarios` WRITE;
/*!40000 ALTER TABLE `comentarios` DISABLE KEYS */;
INSERT INTO `comentarios` VALUES (1,1,1,'Ótima explicação!','2023-01-25 13:00:00'),(2,2,1,'Muito bom!','2023-02-28 14:00:00'),(3,3,2,'Aula interessante.','2023-03-20 15:00:00'),(4,4,2,'Gostei do conteúdo.','2023-05-05 16:00:00'),(5,5,3,'Bem explicado.','2023-06-01 17:00:00'),(6,6,3,'Muito didático.','2023-07-01 18:00:00'),(7,7,4,'Aula excelente.','2023-08-10 19:00:00'),(8,8,4,'Conteúdo claro.','2023-09-01 20:00:00'),(9,9,5,'Gostei muito.','2023-10-01 21:00:00'),(10,10,5,'Boa explicação.','2023-11-01 22:00:00'),(11,11,6,'Conteúdo interessante.','2023-12-01 23:00:00'),(12,12,6,'Muito bom.','2024-01-02 00:00:00'),(13,13,7,'Ótima aula.','2024-02-02 01:00:00'),(14,14,7,'Bem detalhado.','2024-03-02 02:00:00'),(15,15,8,'Explicação clara.','2024-04-01 03:00:00'),(16,16,8,'Muito informativo.','2024-05-01 04:00:00'),(17,17,9,'Gostei do conteúdo.','2024-06-01 05:00:00'),(18,18,9,'Aula muito boa.','2024-07-01 06:00:00'),(19,19,10,'Explicação excelente.','2024-08-01 07:00:00'),(20,20,10,'Conteúdo claro.','2024-09-01 08:00:00'),(21,21,11,'Ótima explicação.','2024-10-01 09:00:00'),(22,22,11,'Muito interessante.','2024-11-01 10:00:00'),(23,23,12,'Bem explicado.','2024-12-01 11:00:00'),(24,24,12,'Gostei muito.','2025-01-01 12:00:00');
/*!40000 ALTER TABLE `comentarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracoes_usuarios`
--

DROP TABLE IF EXISTS `configuracoes_usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracoes_usuarios` (
  `configuracao_id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `preferencia_notificacoes` tinyint(1) DEFAULT '1',
  `preferencia_tema` varchar(20) DEFAULT 'Claro',
  `data_atualizacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`configuracao_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `configuracoes_usuarios_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracoes_usuarios`
--

LOCK TABLES `configuracoes_usuarios` WRITE;
/*!40000 ALTER TABLE `configuracoes_usuarios` DISABLE KEYS */;
INSERT INTO `configuracoes_usuarios` VALUES (1,1,1,'Claro','2024-05-20 22:11:43'),(2,2,0,'Escuro','2024-05-20 22:11:43'),(3,3,1,'Claro','2024-05-20 22:11:43'),(4,4,0,'Escuro','2024-05-20 22:11:43'),(5,5,1,'Claro','2024-05-20 22:11:43'),(6,6,0,'Escuro','2024-05-20 22:11:43'),(7,7,1,'Claro','2024-05-20 22:11:43'),(8,8,0,'Escuro','2024-05-20 22:11:43'),(9,9,1,'Claro','2024-05-20 22:11:43'),(10,10,0,'Escuro','2024-05-20 22:11:43'),(11,11,1,'Claro','2024-05-20 22:11:43'),(12,12,0,'Escuro','2024-05-20 22:11:43'),(13,13,1,'Claro','2024-05-20 22:11:43'),(14,14,0,'Escuro','2024-05-20 22:11:43'),(15,15,1,'Claro','2024-05-20 22:11:43'),(16,16,0,'Escuro','2024-05-20 22:11:43'),(17,17,1,'Claro','2024-05-20 22:11:43'),(18,18,0,'Escuro','2024-05-20 22:11:43'),(19,19,1,'Claro','2024-05-20 22:11:43'),(20,20,0,'Escuro','2024-05-20 22:11:43'),(21,21,1,'Claro','2024-05-20 22:11:43'),(22,22,0,'Escuro','2024-05-20 22:11:43'),(23,23,1,'Claro','2024-05-20 22:11:43'),(24,24,0,'Escuro','2024-05-20 22:11:43'),(25,25,1,'Claro','2024-05-20 22:11:43');
/*!40000 ALTER TABLE `configuracoes_usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `convites`
--

DROP TABLE IF EXISTS `convites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `convites` (
  `convite_id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `email_convidado` varchar(100) NOT NULL,
  `codigo_convite` varchar(50) NOT NULL,
  `data_convite` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Pendente','Aceito','Recusado') DEFAULT 'Pendente',
  PRIMARY KEY (`convite_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `convites_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `convites`
--

LOCK TABLES `convites` WRITE;
/*!40000 ALTER TABLE `convites` DISABLE KEYS */;
INSERT INTO `convites` VALUES (1,1,'convidado1@example.com','INV123','2024-05-20 22:11:43','Pendente'),(2,2,'convidado2@example.com','INV124','2024-05-20 22:11:43','Pendente'),(3,3,'convidado3@example.com','INV125','2024-05-20 22:11:43','Pendente'),(4,4,'convidado4@example.com','INV126','2024-05-20 22:11:43','Pendente'),(5,5,'convidado5@example.com','INV127','2024-05-20 22:11:43','Pendente'),(6,6,'convidado6@example.com','INV128','2024-05-20 22:11:43','Pendente'),(7,7,'convidado7@example.com','INV129','2024-05-20 22:11:43','Pendente'),(8,8,'convidado8@example.com','INV130','2024-05-20 22:11:43','Pendente'),(9,9,'convidado9@example.com','INV131','2024-05-20 22:11:43','Pendente'),(10,10,'convidado10@example.com','INV132','2024-05-20 22:11:43','Pendente'),(11,11,'convidado11@example.com','INV133','2024-05-20 22:11:43','Pendente'),(12,12,'convidado12@example.com','INV134','2024-05-20 22:11:43','Pendente'),(13,13,'convidado13@example.com','INV135','2024-05-20 22:11:43','Pendente'),(14,14,'convidado14@example.com','INV136','2024-05-20 22:11:43','Pendente'),(15,15,'convidado15@example.com','INV137','2024-05-20 22:11:43','Pendente'),(16,16,'convidado16@example.com','INV138','2024-05-20 22:11:43','Pendente'),(17,17,'convidado17@example.com','INV139','2024-05-20 22:11:43','Pendente'),(18,18,'convidado18@example.com','INV140','2024-05-20 22:11:43','Pendente'),(19,19,'convidado19@example.com','INV141','2024-05-20 22:11:43','Pendente'),(20,20,'convidado20@example.com','INV142','2024-05-20 22:11:43','Pendente'),(21,21,'convidado21@example.com','INV143','2024-05-20 22:11:43','Pendente'),(22,22,'convidado22@example.com','INV144','2024-05-20 22:11:43','Pendente'),(23,23,'convidado23@example.com','INV145','2024-05-20 22:11:43','Pendente'),(24,24,'convidado24@example.com','INV146','2024-05-20 22:11:43','Pendente'),(25,25,'convidado25@example.com','INV147','2024-05-20 22:11:43','Pendente');
/*!40000 ALTER TABLE `convites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cupons`
--

DROP TABLE IF EXISTS `cupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cupons` (
  `cupom_id` int NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) NOT NULL,
  `desconto` decimal(5,2) NOT NULL,
  `data_validade` date NOT NULL,
  PRIMARY KEY (`cupom_id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cupons`
--

LOCK TABLES `cupons` WRITE;
/*!40000 ALTER TABLE `cupons` DISABLE KEYS */;
INSERT INTO `cupons` VALUES (1,'PROMO10',10.00,'2024-12-31'),(2,'PROMO20',20.00,'2024-11-30'),(3,'PROMO30',30.00,'2024-10-31'),(4,'PROMO40',40.00,'2024-09-30'),(5,'PROMO50',50.00,'2024-08-31'),(6,'PROMO60',60.00,'2024-07-31'),(7,'PROMO70',70.00,'2024-06-30'),(8,'PROMO80',80.00,'2024-05-31'),(9,'PROMO90',90.00,'2024-04-30'),(10,'PROMO100',100.00,'2024-03-31'),(11,'BLACKFRIDAY',50.00,'2024-11-29'),(12,'CYBERMONDAY',60.00,'2024-12-02'),(13,'NEWYEAR',30.00,'2025-01-01'),(14,'SUMMERSALE',25.00,'2024-06-15'),(15,'WINTERSALE',25.00,'2024-12-15'),(16,'FALLSALE',35.00,'2024-09-15'),(17,'SPRINGSALE',35.00,'2024-03-15'),(18,'VIPDISCOUNT',40.00,'2024-12-31'),(19,'STUDENT10',10.00,'2024-05-31'),(20,'TEACHER20',20.00,'2024-05-31'),(21,'FRIEND25',25.00,'2024-05-31'),(22,'FAMILY30',30.00,'2024-05-31'),(23,'ALUMNI15',15.00,'2024-05-31'),(24,'WELCOME5',5.00,'2024-05-31'),(25,'GOODBYE10',10.00,'2024-12-31');
/*!40000 ALTER TABLE `cupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cursos`
--

DROP TABLE IF EXISTS `cursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cursos` (
  `curso_id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(200) NOT NULL,
  `descricao` text,
  `preco` decimal(10,2) NOT NULL,
  `data_criacao` date NOT NULL,
  `instrutor_id` int DEFAULT NULL,
  PRIMARY KEY (`curso_id`),
  KEY `instrutor_id` (`instrutor_id`),
  CONSTRAINT `cursos_ibfk_1` FOREIGN KEY (`instrutor_id`) REFERENCES `usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cursos`
--

LOCK TABLES `cursos` WRITE;
/*!40000 ALTER TABLE `cursos` DISABLE KEYS */;
INSERT INTO `cursos` VALUES (1,'Curso de Programação Java','Aprenda Java do básico ao avançado.',299.99,'2023-01-15',2),(2,'Curso de Data Science','Domine a ciência de dados com Python.',399.99,'2023-02-20',5),(3,'Curso de Desenvolvimento Web','Crie websites incríveis com HTML, CSS e JavaScript.',199.99,'2023-03-10',8),(4,'Curso de Machine Learning','Aprenda Machine Learning com exemplos práticos.',499.99,'2023-04-25',11),(5,'Curso de Marketing Digital','Torne-se um especialista em marketing digital.',149.99,'2023-05-30',14),(6,'Curso de Design Gráfico','Aprenda as melhores técnicas de design gráfico.',249.99,'2023-06-15',17),(7,'Curso de Fotografia','Domine a arte da fotografia.',99.99,'2023-07-10',20),(8,'Curso de Desenvolvimento Mobile','Crie aplicativos móveis com Android e iOS.',299.99,'2023-08-25',23),(9,'Curso de Inteligência Artificial','Aprenda IA com exemplos práticos.',399.99,'2023-09-15',2),(10,'Curso de E-commerce','Crie e gerencie lojas virtuais de sucesso.',199.99,'2023-10-05',5),(11,'Curso de Finanças Pessoais','Gerencie suas finanças de forma eficiente.',99.99,'2023-11-20',8),(12,'Curso de Inglês','Aprenda inglês de forma prática e eficiente.',149.99,'2023-12-10',11),(13,'Curso de Espanhol','Domine o idioma espanhol.',149.99,'2024-01-15',14),(14,'Curso de Francês','Aprenda francês do básico ao avançado.',149.99,'2024-02-20',17),(15,'Curso de Alemão','Domine o idioma alemão.',149.99,'2024-03-10',20),(16,'Curso de Japonês','Aprenda japonês de forma prática e eficiente.',149.99,'2024-04-25',23),(17,'Curso de Chinês','Domine o idioma chinês.',149.99,'2024-05-30',2),(18,'Curso de Árabe','Aprenda árabe do básico ao avançado.',149.99,'2024-06-15',5),(19,'Curso de Italiano','Domine o idioma italiano.',149.99,'2024-07-10',8),(20,'Curso de Português','Aprenda português de forma prática e eficiente.',149.99,'2024-08-25',11),(21,'Curso de História','Descubra a história mundial.',199.99,'2024-09-15',14),(22,'Curso de Geografia','Explore a geografia mundial.',199.99,'2024-10-05',17),(23,'Curso de Matemática','Domine a matemática do básico ao avançado.',199.99,'2024-11-20',20),(24,'Curso de Física','Aprenda física com exemplos práticos.',199.99,'2024-12-10',23),(25,'Curso de Química','Domine a química do básico ao avançado.',199.99,'2025-01-15',2);
/*!40000 ALTER TABLE `cursos` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `insert_cursos` AFTER INSERT ON `cursos` FOR EACH ROW BEGIN
    INSERT INTO log_cursos (titulo, descricao, preco, data_criacao, instrutor_id, operacao)
    VALUES (NEW.titulo, NEW.descricao, NEW.preco, NEW.data_criacao, NEW.instrutor_id, 2);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `update_cursos` AFTER UPDATE ON `cursos` FOR EACH ROW BEGIN
    INSERT INTO log_cursos (titulo, descricao, preco, data_criacao, instrutor_id, operacao)
    VALUES (OLD.titulo, OLD.descricao, OLD.preco, OLD.data_criacao, OLD.instrutor_id, 3);
    INSERT INTO log_cursos (titulo, descricao, preco, data_criacao, instrutor_id, operacao)
    VALUES (NEW.titulo, NEW.descricao, NEW.preco, NEW.data_criacao, NEW.instrutor_id,  4);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `delete_cursos` BEFORE DELETE ON `cursos` FOR EACH ROW BEGIN
    INSERT INTO log_cursos (titulo, descricao, preco, data_criacao, instrutor_id, operacao)
    VALUES (OLD.titulo, OLD.descricao, OLD.preco, OLD.data_criacao, OLD.instrutor_id, 1);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `cursos_categorias`
--

DROP TABLE IF EXISTS `cursos_categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cursos_categorias` (
  `curso_id` int NOT NULL,
  `categoria_id` int NOT NULL,
  PRIMARY KEY (`curso_id`,`categoria_id`),
  KEY `categoria_id` (`categoria_id`),
  CONSTRAINT `cursos_categorias_ibfk_1` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`curso_id`),
  CONSTRAINT `cursos_categorias_ibfk_2` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`categoria_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cursos_categorias`
--

LOCK TABLES `cursos_categorias` WRITE;
/*!40000 ALTER TABLE `cursos_categorias` DISABLE KEYS */;
INSERT INTO `cursos_categorias` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,2),(7,2),(8,2),(9,2),(10,2),(11,3),(12,3),(13,3),(14,3),(15,3),(16,4),(17,4),(18,4),(19,4),(20,4),(21,5),(22,5),(23,5),(24,5),(25,5);
/*!40000 ALTER TABLE `cursos_categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cursos_cupons`
--

DROP TABLE IF EXISTS `cursos_cupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cursos_cupons` (
  `curso_cupom_id` int NOT NULL AUTO_INCREMENT,
  `curso_id` int DEFAULT NULL,
  `cupom_id` int DEFAULT NULL,
  PRIMARY KEY (`curso_cupom_id`),
  KEY `curso_id` (`curso_id`),
  KEY `cupom_id` (`cupom_id`),
  CONSTRAINT `cursos_cupons_ibfk_1` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`curso_id`),
  CONSTRAINT `cursos_cupons_ibfk_2` FOREIGN KEY (`cupom_id`) REFERENCES `cupons` (`cupom_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cursos_cupons`
--

LOCK TABLES `cursos_cupons` WRITE;
/*!40000 ALTER TABLE `cursos_cupons` DISABLE KEYS */;
INSERT INTO `cursos_cupons` VALUES (1,1,1),(2,1,2),(3,2,3),(4,2,4),(5,3,5),(6,3,6),(7,4,7),(8,4,8),(9,5,9),(10,5,10),(11,6,11),(12,6,12),(13,7,13),(14,7,14),(15,8,15),(16,8,16),(17,9,17),(18,9,18),(19,10,19),(20,10,20),(21,11,21),(22,11,22),(23,12,23),(24,12,24),(25,13,25);
/*!40000 ALTER TABLE `cursos_cupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `descontos_especiais`
--

DROP TABLE IF EXISTS `descontos_especiais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `descontos_especiais` (
  `desconto_especial_id` int NOT NULL AUTO_INCREMENT,
  `curso_id` int DEFAULT NULL,
  `descricao` text,
  `valor_desconto` decimal(5,2) NOT NULL,
  `data_inicio` date NOT NULL,
  `data_fim` date NOT NULL,
  PRIMARY KEY (`desconto_especial_id`),
  KEY `curso_id` (`curso_id`),
  CONSTRAINT `descontos_especiais_ibfk_1` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`curso_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `descontos_especiais`
--

LOCK TABLES `descontos_especiais` WRITE;
/*!40000 ALTER TABLE `descontos_especiais` DISABLE KEYS */;
INSERT INTO `descontos_especiais` VALUES (1,1,'Desconto especial para curso de Python',20.00,'2023-01-01','2023-01-31'),(2,2,'Desconto especial para curso de Java',15.00,'2023-02-01','2023-02-28'),(3,3,'Desconto especial para curso de Data Science',25.00,'2023-03-01','2023-03-31'),(4,4,'Desconto especial para curso de Machine Learning',10.00,'2023-04-01','2023-04-30'),(5,5,'Desconto especial para curso de IA',30.00,'2023-05-01','2023-05-31'),(6,6,'Desconto especial para curso de Web Development',20.00,'2023-06-01','2023-06-30'),(7,7,'Desconto especial para curso de Mobile Development',15.00,'2023-07-01','2023-07-31'),(8,8,'Desconto especial para curso de Segurança Cibernética',25.00,'2023-08-01','2023-08-31'),(9,9,'Desconto especial para curso de Computação em Nuvem',10.00,'2023-09-01','2023-09-30'),(10,10,'Desconto especial para curso de DevOps',30.00,'2023-10-01','2023-10-31'),(11,11,'Desconto especial para curso de UX/UI Design',20.00,'2023-11-01','2023-11-30'),(12,12,'Desconto especial para curso de Marketing Digital',15.00,'2023-12-01','2023-12-31'),(13,13,'Desconto especial para curso de SEO',25.00,'2023-01-01','2023-01-31'),(14,14,'Desconto especial para curso de Gestão de Projetos',10.00,'2023-02-01','2023-02-28'),(15,15,'Desconto especial para curso de Finanças',30.00,'2023-03-01','2023-03-31'),(16,16,'Desconto especial para curso de Fotografia',20.00,'2023-04-01','2023-04-30'),(17,17,'Desconto especial para curso de Música',15.00,'2023-05-01','2023-05-31'),(18,18,'Desconto especial para curso de Línguas',25.00,'2023-06-01','2023-06-30'),(19,19,'Desconto especial para curso de Escrita Criativa',10.00,'2023-07-01','2023-07-31'),(20,20,'Desconto especial para curso de Design Gráfico',30.00,'2023-08-01','2023-08-31'),(21,21,'Desconto especial para curso de E-commerce',20.00,'2023-09-01','2023-09-30'),(22,22,'Desconto especial para curso de habilidades interpessoais',15.00,'2023-10-01','2023-10-31'),(23,23,'Desconto especial para curso de Coaching',25.00,'2023-11-01','2023-11-30'),(24,24,'Desconto especial para curso de Treinamento Pessoal',10.00,'2023-12-01','2023-12-31'),(25,25,'Desconto especial para curso de Educação Infantil',30.00,'2023-01-01','2023-01-31');
/*!40000 ALTER TABLE `descontos_especiais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favoritos`
--

DROP TABLE IF EXISTS `favoritos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favoritos` (
  `favorito_id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `curso_id` int DEFAULT NULL,
  `data_favorito` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`favorito_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `curso_id` (`curso_id`),
  CONSTRAINT `favoritos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`),
  CONSTRAINT `favoritos_ibfk_2` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`curso_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favoritos`
--

LOCK TABLES `favoritos` WRITE;
/*!40000 ALTER TABLE `favoritos` DISABLE KEYS */;
INSERT INTO `favoritos` VALUES (1,1,1,'2024-05-20 22:11:43'),(2,2,1,'2024-05-20 22:11:43'),(3,3,2,'2024-05-20 22:11:43'),(4,4,2,'2024-05-20 22:11:43'),(5,5,3,'2024-05-20 22:11:43'),(6,6,3,'2024-05-20 22:11:43'),(7,7,4,'2024-05-20 22:11:43'),(8,8,4,'2024-05-20 22:11:43'),(9,9,5,'2024-05-20 22:11:43'),(10,10,5,'2024-05-20 22:11:43'),(11,11,6,'2024-05-20 22:11:43'),(12,12,6,'2024-05-20 22:11:43'),(13,13,7,'2024-05-20 22:11:43'),(14,14,7,'2024-05-20 22:11:43'),(15,15,8,'2024-05-20 22:11:43'),(16,16,8,'2024-05-20 22:11:43'),(17,17,9,'2024-05-20 22:11:43'),(18,18,9,'2024-05-20 22:11:43'),(19,19,10,'2024-05-20 22:11:43'),(20,20,10,'2024-05-20 22:11:43'),(21,21,11,'2024-05-20 22:11:43'),(22,22,11,'2024-05-20 22:11:43'),(23,23,12,'2024-05-20 22:11:43'),(24,24,12,'2024-05-20 22:11:43'),(25,25,13,'2024-05-20 22:11:43');
/*!40000 ALTER TABLE `favoritos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forums`
--

DROP TABLE IF EXISTS `forums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forums` (
  `forum_id` int NOT NULL AUTO_INCREMENT,
  `curso_id` int DEFAULT NULL,
  `titulo` varchar(200) NOT NULL,
  `descricao` text,
  `data_criacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`forum_id`),
  KEY `curso_id` (`curso_id`),
  CONSTRAINT `forums_ibfk_1` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`curso_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forums`
--

LOCK TABLES `forums` WRITE;
/*!40000 ALTER TABLE `forums` DISABLE KEYS */;
INSERT INTO `forums` VALUES (1,1,'Fórum de Python','Discussões sobre o curso de Python.','2024-05-20 22:11:43'),(2,2,'Fórum de Java','Discussões sobre o curso de Java.','2024-05-20 22:11:43'),(3,3,'Fórum de Data Science','Discussões sobre o curso de Data Science.','2024-05-20 22:11:43'),(4,4,'Fórum de Machine Learning','Discussões sobre o curso de Machine Learning.','2024-05-20 22:11:43'),(5,5,'Fórum de Inteligência Artificial','Discussões sobre o curso de IA.','2024-05-20 22:11:43'),(6,6,'Fórum de Web Development','Discussões sobre o curso de Desenvolvimento Web.','2024-05-20 22:11:43'),(7,7,'Fórum de Mobile Development','Discussões sobre o curso de Desenvolvimento Mobile.','2024-05-20 22:11:43'),(8,8,'Fórum de Cybersecurity','Discussões sobre o curso de Segurança Cibernética.','2024-05-20 22:11:43'),(9,9,'Fórum de Cloud Computing','Discussões sobre o curso de Computação em Nuvem.','2024-05-20 22:11:43'),(10,10,'Fórum de DevOps','Discussões sobre o curso de DevOps.','2024-05-20 22:11:43'),(11,11,'Fórum de UX/UI','Discussões sobre o curso de UX/UI Design.','2024-05-20 22:11:43'),(12,12,'Fórum de Marketing Digital','Discussões sobre o curso de Marketing Digital.','2024-05-20 22:11:43'),(13,13,'Fórum de SEO','Discussões sobre o curso de SEO.','2024-05-20 22:11:43'),(14,14,'Fórum de Gestão de Projetos','Discussões sobre o curso de Gestão de Projetos.','2024-05-20 22:11:43'),(15,15,'Fórum de Finanças','Discussões sobre o curso de Finanças.','2024-05-20 22:11:43'),(16,16,'Fórum de Fotografia','Discussões sobre o curso de Fotografia.','2024-05-20 22:11:43'),(17,17,'Fórum de Música','Discussões sobre o curso de Música.','2024-05-20 22:11:43'),(18,18,'Fórum de Línguas','Discussões sobre cursos de idiomas.','2024-05-20 22:11:43'),(19,19,'Fórum de Escrita','Discussões sobre o curso de Escrita Criativa.','2024-05-20 22:11:43'),(20,20,'Fórum de Design','Discussões sobre o curso de Design Gráfico.','2024-05-20 22:11:43'),(21,21,'Fórum de E-commerce','Discussões sobre o curso de E-commerce.','2024-05-20 22:11:43'),(22,22,'Fórum de Soft Skills','Discussões sobre cursos de habilidades interpessoais.','2024-05-20 22:11:43'),(23,23,'Fórum de Coaching','Discussões sobre o curso de Coaching.','2024-05-20 22:11:43'),(24,24,'Fórum de Treinamento Pessoal','Discussões sobre o curso de Treinamento Pessoal.','2024-05-20 22:11:43'),(25,25,'Fórum de Educação Infantil','Discussões sobre o curso de Educação Infantil.','2024-05-20 22:11:43');
/*!40000 ALTER TABLE `forums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_certificados`
--

DROP TABLE IF EXISTS `log_certificados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_certificados` (
  `log_certificados_id` int NOT NULL AUTO_INCREMENT,
  `certificado_id` int DEFAULT NULL,
  `matricula_id` int DEFAULT NULL,
  `data_emissao` date DEFAULT NULL,
  `codigo_validacao` varchar(100) DEFAULT NULL,
  `operacao` int DEFAULT NULL,
  PRIMARY KEY (`log_certificados_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_certificados`
--

LOCK TABLES `log_certificados` WRITE;
/*!40000 ALTER TABLE `log_certificados` DISABLE KEYS */;
INSERT INTO `log_certificados` VALUES (1,26,1,'1987-10-10','10',2),(2,26,1,'1987-10-10','10',3),(3,26,1,'1987-10-10','15',4),(4,26,1,'1987-10-10','15',1);
/*!40000 ALTER TABLE `log_certificados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_cursos`
--

DROP TABLE IF EXISTS `log_cursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_cursos` (
  `log_cursos_id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(200) DEFAULT NULL,
  `descricao` text,
  `preco` decimal(10,2) DEFAULT NULL,
  `data_criacao` date DEFAULT NULL,
  `instrutor_id` int DEFAULT NULL,
  `operacao` int DEFAULT NULL,
  PRIMARY KEY (`log_cursos_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_cursos`
--

LOCK TABLES `log_cursos` WRITE;
/*!40000 ALTER TABLE `log_cursos` DISABLE KEYS */;
INSERT INTO `log_cursos` VALUES (1,'Texte','texte',1001.00,'2000-02-10',2,2),(2,'Texte','texte',1001.00,'2000-02-10',2,3),(3,'Thor','texte',1001.00,'2000-02-10',2,4),(4,'Thor','texte',1001.00,'2000-02-10',2,1);
/*!40000 ALTER TABLE `log_cursos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_matriculas`
--

DROP TABLE IF EXISTS `log_matriculas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_matriculas` (
  `log_matriculas_id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `curso_id` int DEFAULT NULL,
  `data_matricula` date DEFAULT NULL,
  `operacao` int DEFAULT NULL,
  PRIMARY KEY (`log_matriculas_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_matriculas`
--

LOCK TABLES `log_matriculas` WRITE;
/*!40000 ALTER TABLE `log_matriculas` DISABLE KEYS */;
INSERT INTO `log_matriculas` VALUES (1,1,1,'1987-10-10',2),(2,1,1,'1987-10-10',3),(3,1,1,'1987-10-15',4),(4,1,1,'1987-10-15',1);
/*!40000 ALTER TABLE `log_matriculas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_pagamentos`
--

DROP TABLE IF EXISTS `log_pagamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_pagamentos` (
  `log_pagamentos_id` int NOT NULL AUTO_INCREMENT,
  `matricula_id` int DEFAULT NULL,
  `data_pagamento` date DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `metodo_pagamento` varchar(50) DEFAULT NULL,
  `operacao` int DEFAULT NULL,
  PRIMARY KEY (`log_pagamentos_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_pagamentos`
--

LOCK TABLES `log_pagamentos` WRITE;
/*!40000 ALTER TABLE `log_pagamentos` DISABLE KEYS */;
INSERT INTO `log_pagamentos` VALUES (1,1,'2000-02-10',12.00,'cartao',2),(2,1,'2000-02-10',12.00,'cartao',3),(3,1,'2000-02-10',15.00,'cartao',4),(4,1,'2000-02-10',15.00,'cartao',1);
/*!40000 ALTER TABLE `log_pagamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_usuarios`
--

DROP TABLE IF EXISTS `log_usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_usuarios` (
  `log_usuarios_id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `senha` varchar(100) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `tipo` enum('Aluno','Instrutor','Adminstrador') DEFAULT NULL,
  `operacao` int DEFAULT NULL,
  PRIMARY KEY (`log_usuarios_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_usuarios`
--

LOCK TABLES `log_usuarios` WRITE;
/*!40000 ALTER TABLE `log_usuarios` DISABLE KEYS */;
INSERT INTO `log_usuarios` VALUES (1,'Zé Paulo','emxemplo@email.com','123456','2000-02-10','Rua 10 Lote 1','(61) 988874411','Aluno',2),(2,'Zé Paulo','emxemplo@email.com','123456','2000-02-10','Rua 10 Lote 1','(61) 988874411','Aluno',1),(3,'Zé Paulo','emxemplo@email.com','123456','2000-02-10','Rua 10 Lote 1','(61) 988874411','Aluno',2),(4,'Zé Paulo','emxemplo@email.com','123456','2000-02-10','Rua 10 Lote 1','(61) 988874411','Aluno',3),(5,'Thor','emxemplo@email.com','123456','2000-02-10','Rua 10 Lote 1','(61) 988874411','Aluno',4),(6,'Thor','emxemplo@email.com','123456','2000-02-10','Rua 10 Lote 1','(61) 988874411','Aluno',1);
/*!40000 ALTER TABLE `log_usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs_acesso`
--

DROP TABLE IF EXISTS `logs_acesso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs_acesso` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `DESCRICAO` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs_acesso`
--

LOCK TABLES `logs_acesso` WRITE;
/*!40000 ALTER TABLE `logs_acesso` DISABLE KEYS */;
INSERT INTO `logs_acesso` VALUES (1,'DELETE'),(2,'INSERT'),(3,'UPDATE DADOS ANTIGOS'),(4,'UPDATE DADOS NOVOS');
/*!40000 ALTER TABLE `logs_acesso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matriculas`
--

DROP TABLE IF EXISTS `matriculas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matriculas` (
  `matricula_id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `curso_id` int DEFAULT NULL,
  `data_matricula` date NOT NULL,
  PRIMARY KEY (`matricula_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `curso_id` (`curso_id`),
  CONSTRAINT `matriculas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`),
  CONSTRAINT `matriculas_ibfk_2` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`curso_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matriculas`
--

LOCK TABLES `matriculas` WRITE;
/*!40000 ALTER TABLE `matriculas` DISABLE KEYS */;
INSERT INTO `matriculas` VALUES (1,1,1,'2023-01-20'),(2,1,2,'2023-02-25'),(3,2,3,'2023-03-15'),(4,2,4,'2023-04-30'),(5,3,5,'2023-05-25'),(6,3,6,'2023-06-20'),(7,4,7,'2023-07-15'),(8,4,8,'2023-08-30'),(9,5,9,'2023-09-20'),(10,5,10,'2023-10-15'),(11,6,11,'2023-11-25'),(12,6,12,'2023-12-20'),(13,7,13,'2024-01-15'),(14,7,14,'2024-02-25'),(15,8,15,'2024-03-15'),(16,8,16,'2024-04-30'),(17,9,17,'2024-05-25'),(18,9,18,'2024-06-20'),(19,10,19,'2024-07-15'),(20,10,20,'2024-08-30'),(21,11,21,'2024-09-20'),(22,11,22,'2024-10-15'),(23,12,23,'2024-11-25'),(24,12,24,'2024-12-20'),(25,13,25,'2025-01-15');
/*!40000 ALTER TABLE `matriculas` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `insert_matriculas` AFTER INSERT ON `matriculas` FOR EACH ROW BEGIN
    INSERT INTO log_matriculas(usuario_id, curso_id, data_matricula, operacao)
    VALUES (NEW.usuario_id, NEW.curso_id, NEW.data_matricula, 2);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `update_matriculas` AFTER UPDATE ON `matriculas` FOR EACH ROW BEGIN
    INSERT INTO log_matriculas (usuario_id, curso_id, data_matricula, operacao)
    VALUES (OLD.usuario_id, OLD.curso_id, OLD.data_matricula, 3);
    INSERT INTO log_matriculas (usuario_id, curso_id, data_matricula, operacao)
    VALUES (NEW.usuario_id, NEW.curso_id, NEW.data_matricula,  4);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `delete_matriculas` BEFORE DELETE ON `matriculas` FOR EACH ROW BEGIN
    INSERT INTO log_matriculas (usuario_id, curso_id, data_matricula, operacao)
    VALUES (OLD.usuario_id, OLD.curso_id, OLD.data_matricula, 1);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary view structure for view `matriculas_mes_atual`
--

DROP TABLE IF EXISTS `matriculas_mes_atual`;
/*!50001 DROP VIEW IF EXISTS `matriculas_mes_atual`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `matriculas_mes_atual` AS SELECT 
 1 AS `matricula_id`,
 1 AS `usuario_id`,
 1 AS `curso_id`,
 1 AS `data_matricula`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `modulos`
--

DROP TABLE IF EXISTS `modulos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modulos` (
  `modulo_id` int NOT NULL AUTO_INCREMENT,
  `curso_id` int DEFAULT NULL,
  `titulo` varchar(200) NOT NULL,
  `descricao` text,
  `ordem` int NOT NULL,
  PRIMARY KEY (`modulo_id`),
  KEY `curso_id` (`curso_id`),
  CONSTRAINT `modulos_ibfk_1` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`curso_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modulos`
--

LOCK TABLES `modulos` WRITE;
/*!40000 ALTER TABLE `modulos` DISABLE KEYS */;
INSERT INTO `modulos` VALUES (1,1,'Introdução ao Java','Primeiros passos com Java.',1),(2,1,'Estruturas de Controle','Controle de fluxo em Java.',2),(3,1,'Programação Orientada a Objetos','Conceitos de OOP em Java.',3),(4,1,'Coleções em Java','Trabalhando com coleções em Java.',4),(5,1,'Java Avançado','Tópicos avançados de Java.',5),(6,2,'Introdução ao Data Science','Primeiros passos com Data Science.',1),(7,2,'Estatística Básica','Conceitos básicos de estatística.',2),(8,2,'Manipulação de Dados','Trabalhando com dados em Python.',3),(9,2,'Visualização de Dados','Criando visualizações com Python.',4),(10,2,'Machine Learning','Algoritmos de Machine Learning.',5),(11,3,'HTML Básico','Introdução ao HTML.',1),(12,3,'CSS Básico','Introdução ao CSS.',2),(13,3,'JavaScript Básico','Introdução ao JavaScript.',3),(14,3,'Frameworks CSS','Trabalhando com frameworks CSS.',4),(15,3,'JavaScript Avançado','Tópicos avançados de JavaScript.',5),(16,4,'Introdução ao Machine Learning','Primeiros passos com Machine Learning.',1),(17,4,'Algoritmos Supervisionados','Algoritmos de aprendizado supervisionado.',2),(18,4,'Algoritmos Não Supervisionados','Algoritmos de aprendizado não supervisionado.',3),(19,4,'Redes Neurais','Introdução às redes neurais.',4),(20,4,'Projetos de Machine Learning','Implementação de projetos de ML.',5),(21,5,'Fundamentos do Marketing Digital','Primeiros passos no marketing digital.',1),(22,5,'SEO','Otimização para mecanismos de busca.',2),(23,5,'Redes Sociais','Marketing em redes sociais.',3),(24,5,'E-mail Marketing','Campanhas de e-mail marketing.',4),(25,5,'Análise de Resultados','Análise de métricas e resultados.',5);
/*!40000 ALTER TABLE `modulos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificacoes`
--

DROP TABLE IF EXISTS `notificacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notificacoes` (
  `notificacao_id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `mensagem` text NOT NULL,
  `lida` tinyint(1) DEFAULT '0',
  `data_notificacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notificacao_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `notificacoes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificacoes`
--

LOCK TABLES `notificacoes` WRITE;
/*!40000 ALTER TABLE `notificacoes` DISABLE KEYS */;
INSERT INTO `notificacoes` VALUES (1,1,'Você tem um novo curso disponível.',0,'2024-05-20 22:11:43'),(2,2,'Seu pagamento foi aprovado.',0,'2024-05-20 22:11:43'),(3,3,'Seu certificado está disponível para download.',0,'2024-05-20 22:11:43'),(4,4,'Nova mensagem no fórum do curso.',0,'2024-05-20 22:11:43'),(5,5,'Você recebeu um novo cupom de desconto.',0,'2024-05-20 22:11:43'),(6,6,'Curso atualizado com novos conteúdos.',0,'2024-05-20 22:11:43'),(7,7,'Parabéns por concluir o curso!',0,'2024-05-20 22:11:43'),(8,8,'Você foi marcado em um comentário.',0,'2024-05-20 22:11:43'),(9,9,'Nova resposta na sua pergunta.',0,'2024-05-20 22:11:43'),(10,10,'Seu ticket de suporte foi respondido.',0,'2024-05-20 22:11:43'),(11,11,'Novo curso adicionado à sua categoria favorita.',0,'2024-05-20 22:11:43'),(12,12,'Seu progresso foi salvo.',0,'2024-05-20 22:11:43'),(13,13,'Você foi adicionado a um novo grupo de estudo.',0,'2024-05-20 22:11:43'),(14,14,'Seu certificado foi revalidado.',0,'2024-05-20 22:11:43'),(15,15,'Nova aula disponível no curso.',0,'2024-05-20 22:11:43'),(16,16,'Você tem um novo convite para o curso.',0,'2024-05-20 22:11:43'),(17,17,'Seu comentário recebeu uma resposta.',0,'2024-05-20 22:11:43'),(18,18,'Nova avaliação no curso.',0,'2024-05-20 22:11:43'),(19,19,'Você ganhou um badge de conclusão.',0,'2024-05-20 22:11:43'),(20,20,'Nova notificação de evento ao vivo.',0,'2024-05-20 22:11:43'),(21,21,'Seu curso está em promoção.',0,'2024-05-20 22:11:43'),(22,22,'Seu cupom está prestes a expirar.',0,'2024-05-20 22:11:43'),(23,23,'Novo curso recomendado para você.',0,'2024-05-20 22:11:43'),(24,24,'Seu pagamento foi recusado.',0,'2024-05-20 22:11:43'),(25,25,'Seu ticket de suporte foi fechado.',0,'2024-05-20 22:11:43');
/*!40000 ALTER TABLE `notificacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagamentos`
--

DROP TABLE IF EXISTS `pagamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagamentos` (
  `pagamento_id` int NOT NULL AUTO_INCREMENT,
  `matricula_id` int DEFAULT NULL,
  `data_pagamento` date NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `metodo_pagamento` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`pagamento_id`),
  KEY `matricula_id` (`matricula_id`),
  CONSTRAINT `pagamentos_ibfk_1` FOREIGN KEY (`matricula_id`) REFERENCES `matriculas` (`matricula_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagamentos`
--

LOCK TABLES `pagamentos` WRITE;
/*!40000 ALTER TABLE `pagamentos` DISABLE KEYS */;
INSERT INTO `pagamentos` VALUES (1,1,'2023-01-21',299.99,'Cartão de Crédito'),(2,2,'2023-02-26',399.99,'Cartão de Crédito'),(3,3,'2023-03-16',199.99,'Boleto Bancário'),(4,4,'2023-05-01',499.99,'Cartão de Crédito'),(5,5,'2023-06-02',149.99,'Paypal'),(6,6,'2023-07-02',249.99,'Cartão de Crédito'),(7,7,'2023-08-11',99.99,'Cartão de Crédito'),(8,8,'2023-09-02',299.99,'Boleto Bancário'),(9,9,'2023-10-02',399.99,'Paypal'),(10,10,'2023-11-02',199.99,'Cartão de Crédito'),(11,11,'2023-12-02',99.99,'Cartão de Crédito'),(12,12,'2024-01-02',149.99,'Boleto Bancário'),(13,13,'2024-02-02',149.99,'Cartão de Crédito'),(14,14,'2024-03-02',149.99,'Paypal'),(15,15,'2024-04-02',149.99,'Cartão de Crédito'),(16,16,'2024-05-02',149.99,'Boleto Bancário'),(17,17,'2024-06-02',149.99,'Cartão de Crédito'),(18,18,'2024-07-02',149.99,'Paypal'),(19,19,'2024-08-02',149.99,'Cartão de Crédito'),(20,20,'2024-09-02',199.99,'Boleto Bancário'),(21,21,'2024-10-02',199.99,'Cartão de Crédito'),(22,22,'2024-11-02',199.99,'Paypal'),(23,23,'2024-12-02',199.99,'Cartão de Crédito'),(24,24,'2025-01-02',199.99,'Boleto Bancário'),(25,25,'2025-02-02',199.99,'Cartão de Crédito');
/*!40000 ALTER TABLE `pagamentos` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `insert_pagamentos` AFTER INSERT ON `pagamentos` FOR EACH ROW BEGIN
    INSERT INTO log_pagamentos (matricula_id, data_pagamento, valor, metodo_pagamento, operacao)
    VALUES (NEW.matricula_id, NEW.data_pagamento, NEW.valor, NEW.metodo_pagamento, 2);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `update_pagamentos` AFTER UPDATE ON `pagamentos` FOR EACH ROW BEGIN
    INSERT INTO log_pagamentos (matricula_id, data_pagamento, valor, metodo_pagamento, operacao)
    VALUES (OLD.matricula_id, OLD.data_pagamento, OLD.valor, OLD.metodo_pagamento, 3);
    INSERT INTO log_pagamentos (matricula_id, data_pagamento, valor, metodo_pagamento, operacao)
    VALUES (NEW.matricula_id, NEW.data_pagamento, NEW.valor, NEW.metodo_pagamento,  4);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `delete_pagamentos` BEFORE DELETE ON `pagamentos` FOR EACH ROW BEGIN
    INSERT INTO log_pagamentos (matricula_id, data_pagamento, valor, metodo_pagamento, operacao)
    VALUES (OLD.matricula_id, OLD.data_pagamento, OLD.valor, OLD.metodo_pagamento, 1);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `perguntas`
--

DROP TABLE IF EXISTS `perguntas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `perguntas` (
  `pergunta_id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `curso_id` int DEFAULT NULL,
  `modulo_id` int DEFAULT NULL,
  `aula_id` int DEFAULT NULL,
  `pergunta` text NOT NULL,
  `data_pergunta` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pergunta_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `curso_id` (`curso_id`),
  KEY `modulo_id` (`modulo_id`),
  KEY `aula_id` (`aula_id`),
  CONSTRAINT `perguntas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`),
  CONSTRAINT `perguntas_ibfk_2` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`curso_id`),
  CONSTRAINT `perguntas_ibfk_3` FOREIGN KEY (`modulo_id`) REFERENCES `modulos` (`modulo_id`),
  CONSTRAINT `perguntas_ibfk_4` FOREIGN KEY (`aula_id`) REFERENCES `aulas` (`aula_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `perguntas`
--

LOCK TABLES `perguntas` WRITE;
/*!40000 ALTER TABLE `perguntas` DISABLE KEYS */;
INSERT INTO `perguntas` VALUES (1,1,1,1,1,'Como instalar o software?','2024-05-20 22:11:43'),(2,2,1,1,2,'Qual é o requisito básico?','2024-05-20 22:11:43'),(3,3,2,2,3,'Qual é a duração do curso?','2024-05-20 22:11:43'),(4,4,2,2,4,'Como acessar o material?','2024-05-20 22:11:43'),(5,5,3,3,5,'O curso oferece certificado?','2024-05-20 22:11:43'),(6,6,3,3,6,'Posso assistir offline?','2024-05-20 22:11:43'),(7,7,4,4,7,'Qual é a política de reembolso?','2024-05-20 22:11:43'),(8,8,4,4,8,'O curso tem suporte ao vivo?','2024-05-20 22:11:43'),(9,9,5,5,9,'Como tirar dúvidas?','2024-05-20 22:11:43'),(10,10,5,5,10,'O curso é para iniciantes?','2024-05-20 22:11:43'),(11,11,6,6,11,'Há algum pré-requisito?','2024-05-20 22:11:43'),(12,12,6,6,12,'O curso tem exercícios práticos?','2024-05-20 22:11:43'),(13,13,7,7,13,'Qual é a metodologia de ensino?','2024-05-20 22:11:43'),(14,14,7,7,14,'O curso tem prazo de conclusão?','2024-05-20 22:11:43'),(15,15,8,8,15,'Como baixar os slides?','2024-05-20 22:11:43'),(16,16,8,8,16,'Qual é a nota mínima para aprovação?','2024-05-20 22:11:43'),(17,17,9,9,17,'O curso tem suporte em português?','2024-05-20 22:11:43'),(18,18,9,9,18,'Posso compartilhar o conteúdo?','2024-05-20 22:11:43'),(19,19,10,10,19,'O curso é reconhecido pelo MEC?','2024-05-20 22:11:43'),(20,20,10,10,20,'Há aulas ao vivo?','2024-05-20 22:11:43'),(21,21,11,11,21,'O curso é 100% online?','2024-05-20 22:11:43'),(22,22,11,11,22,'Como acessar o fórum?','2024-05-20 22:11:43'),(23,23,12,12,23,'Qual é a carga horária?','2024-05-20 22:11:43');
/*!40000 ALTER TABLE `perguntas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `progresso`
--

DROP TABLE IF EXISTS `progresso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `progresso` (
  `progresso_id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `curso_id` int DEFAULT NULL,
  `modulo_id` int DEFAULT NULL,
  `aula_id` int DEFAULT NULL,
  `status` enum('Não iniciado','Em progresso','Concluído') NOT NULL,
  `data_ultima_atualizacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`progresso_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `curso_id` (`curso_id`),
  KEY `modulo_id` (`modulo_id`),
  KEY `aula_id` (`aula_id`),
  CONSTRAINT `progresso_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`),
  CONSTRAINT `progresso_ibfk_2` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`curso_id`),
  CONSTRAINT `progresso_ibfk_3` FOREIGN KEY (`modulo_id`) REFERENCES `modulos` (`modulo_id`),
  CONSTRAINT `progresso_ibfk_4` FOREIGN KEY (`aula_id`) REFERENCES `aulas` (`aula_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `progresso`
--

LOCK TABLES `progresso` WRITE;
/*!40000 ALTER TABLE `progresso` DISABLE KEYS */;
INSERT INTO `progresso` VALUES (1,1,1,1,1,'Em progresso','2024-05-20 22:11:43'),(2,2,1,1,2,'Em progresso','2024-05-20 22:11:43'),(3,3,2,2,3,'Concluído','2024-05-20 22:11:43'),(4,4,2,2,4,'Não iniciado','2024-05-20 22:11:43'),(5,5,3,3,5,'Concluído','2024-05-20 22:11:43'),(6,6,3,3,6,'Em progresso','2024-05-20 22:11:43'),(7,7,4,4,7,'Não iniciado','2024-05-20 22:11:43'),(8,8,4,4,8,'Em progresso','2024-05-20 22:11:43'),(9,9,5,5,9,'Concluído','2024-05-20 22:11:43'),(10,10,5,5,10,'Não iniciado','2024-05-20 22:11:43'),(11,11,6,6,11,'Em progresso','2024-05-20 22:11:43'),(12,12,6,6,12,'Concluído','2024-05-20 22:11:43'),(13,13,7,7,13,'Não iniciado','2024-05-20 22:11:43'),(14,14,7,7,14,'Em progresso','2024-05-20 22:11:43'),(15,15,8,8,15,'Concluído','2024-05-20 22:11:43'),(16,16,8,8,16,'Em progresso','2024-05-20 22:11:43'),(17,17,9,9,17,'Não iniciado','2024-05-20 22:11:43'),(18,18,9,9,18,'Concluído','2024-05-20 22:11:43'),(19,19,10,10,19,'Em progresso','2024-05-20 22:11:43'),(20,20,10,10,20,'Concluído','2024-05-20 22:11:43'),(21,21,11,11,21,'Não iniciado','2024-05-20 22:11:43'),(22,22,11,11,22,'Em progresso','2024-05-20 22:11:43'),(23,23,12,12,23,'Concluído','2024-05-20 22:11:43'),(24,24,12,12,24,'Em progresso','2024-05-20 22:11:43');
/*!40000 ALTER TABLE `progresso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `respostas_perguntas`
--

DROP TABLE IF EXISTS `respostas_perguntas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `respostas_perguntas` (
  `resposta_pergunta_id` int NOT NULL AUTO_INCREMENT,
  `pergunta_id` int DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  `resposta` text NOT NULL,
  `data_resposta` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`resposta_pergunta_id`),
  KEY `pergunta_id` (`pergunta_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `respostas_perguntas_ibfk_1` FOREIGN KEY (`pergunta_id`) REFERENCES `perguntas` (`pergunta_id`),
  CONSTRAINT `respostas_perguntas_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `respostas_perguntas`
--

LOCK TABLES `respostas_perguntas` WRITE;
/*!40000 ALTER TABLE `respostas_perguntas` DISABLE KEYS */;
INSERT INTO `respostas_perguntas` VALUES (1,1,1,'Você pode instalar através do site oficial.','2024-05-20 22:11:43'),(2,2,2,'O requisito básico é ter conhecimento em informática.','2024-05-20 22:11:43'),(3,3,3,'A duração do curso é de 4 semanas.','2024-05-20 22:11:43'),(4,4,4,'O material está disponível na aba de recursos.','2024-05-20 22:11:43'),(5,5,5,'Sim, o curso oferece certificado de conclusão.','2024-05-20 22:11:43'),(6,6,6,'Não, o curso só pode ser assistido online.','2024-05-20 22:11:43'),(7,7,7,'A política de reembolso está descrita no site.','2024-05-20 22:11:43'),(8,8,8,'Sim, há suporte ao vivo durante as aulas.','2024-05-20 22:11:43'),(9,9,9,'Você pode tirar dúvidas no fórum do curso.','2024-05-20 22:11:43'),(10,10,10,'Sim, o curso é voltado para iniciantes.','2024-05-20 22:11:43'),(11,11,11,'Não há pré-requisitos para este curso.','2024-05-20 22:11:43'),(12,12,12,'Sim, há exercícios práticos ao final de cada módulo.','2024-05-20 22:11:43'),(13,13,13,'A metodologia é baseada em aulas teóricas e práticas.','2024-05-20 22:11:43'),(14,14,14,'Não, o curso pode ser concluído no seu tempo.','2024-05-20 22:11:43'),(15,15,15,'Os slides podem ser baixados na aba de materiais.','2024-05-20 22:11:43'),(16,16,16,'A nota mínima para aprovação é 70%.','2024-05-20 22:11:43'),(17,17,17,'Sim, o curso tem suporte em português.','2024-05-20 22:11:43'),(18,18,18,'O conteúdo pode ser compartilhado com restrições.','2024-05-20 22:11:43'),(19,19,19,'Sim, o curso é reconhecido pelo MEC.','2024-05-20 22:11:43'),(20,20,20,'Sim, há aulas ao vivo todas as sextas-feiras.','2024-05-20 22:11:43'),(21,21,21,'Sim, o curso é 100% online.','2024-05-20 22:11:43'),(22,22,22,'O fórum pode ser acessado na aba de comunidade.','2024-05-20 22:11:43'),(23,23,23,'A carga horária é de 40 horas.','2024-05-20 22:11:43');
/*!40000 ALTER TABLE `respostas_perguntas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `respostas_tickets`
--

DROP TABLE IF EXISTS `respostas_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `respostas_tickets` (
  `resposta_id` int NOT NULL AUTO_INCREMENT,
  `ticket_id` int DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  `resposta` text NOT NULL,
  `data_resposta` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`resposta_id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `respostas_tickets_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets_suporte` (`ticket_id`),
  CONSTRAINT `respostas_tickets_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `respostas_tickets`
--

LOCK TABLES `respostas_tickets` WRITE;
/*!40000 ALTER TABLE `respostas_tickets` DISABLE KEYS */;
INSERT INTO `respostas_tickets` VALUES (1,1,1,'Estamos verificando o problema.','2024-05-20 22:11:43'),(2,2,2,'Pagamento foi processado com sucesso.','2024-05-20 22:11:43'),(3,3,3,'Certificado será emitido em breve.','2024-05-20 22:11:43'),(4,4,4,'Instale o Python através do site oficial.','2024-05-20 22:11:43'),(5,5,5,'Tente limpar o cache do navegador.','2024-05-20 22:11:43'),(6,6,6,'Atualizaremos o conteúdo em breve.','2024-05-20 22:11:43'),(7,7,7,'Corrigiremos o erro no certificado.','2024-05-20 22:11:43'),(8,8,8,'Por favor, tente novamente mais tarde.','2024-05-20 22:11:43'),(9,9,9,'Aplique técnicas de SEO conforme indicado no curso.','2024-05-20 22:11:43'),(10,10,10,'Estamos verificando o problema no certificado.','2024-05-20 22:11:43'),(11,11,11,'Tente ajustar a qualidade do vídeo.','2024-05-20 22:11:43'),(12,12,12,'Para campanhas no Facebook, siga as instruções do curso.','2024-05-20 22:11:43'),(13,13,13,'Estamos verificando o problema no site.','2024-05-20 22:11:43'),(14,14,14,'Pagamento duplicado será reembolsado.','2024-05-20 22:11:43'),(15,15,15,'Certificado será emitido em breve.','2024-05-20 22:11:43'),(16,16,16,'Estamos verificando a disponibilidade da aula.','2024-05-20 22:11:43'),(17,17,17,'Redefina sua senha e tente novamente.','2024-05-20 22:11:43'),(18,18,18,'Estamos corrigindo os erros no curso.','2024-05-20 22:11:43'),(19,19,19,'Instale bibliotecas através do pip.','2024-05-20 22:11:43'),(20,20,20,'Verifique se todos os dados estão corretos.','2024-05-20 22:11:43'),(21,21,21,'Pagamento foi processado com sucesso.','2024-05-20 22:11:43'),(22,22,22,'Recomendamos câmeras da marca Canon.','2024-05-20 22:11:43'),(23,23,23,'Tente limpar o cache do navegador.','2024-05-20 22:11:43'),(24,24,24,'Estamos verificando o problema de acesso.','2024-05-20 22:11:43'),(25,25,25,'Utilize o Photoshop conforme instruído no curso.','2024-05-20 22:11:43');
/*!40000 ALTER TABLE `respostas_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `respostas_topicos`
--

DROP TABLE IF EXISTS `respostas_topicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `respostas_topicos` (
  `resposta_topico_id` int NOT NULL AUTO_INCREMENT,
  `topico_id` int DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  `resposta` text NOT NULL,
  `data_resposta` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`resposta_topico_id`),
  KEY `topico_id` (`topico_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `respostas_topicos_ibfk_1` FOREIGN KEY (`topico_id`) REFERENCES `topicos_forum` (`topico_id`),
  CONSTRAINT `respostas_topicos_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `respostas_topicos`
--

LOCK TABLES `respostas_topicos` WRITE;
/*!40000 ALTER TABLE `respostas_topicos` DISABLE KEYS */;
INSERT INTO `respostas_topicos` VALUES (1,1,2,'Você pode baixar o Python no site oficial e seguir o guia de instalação.','2024-05-20 22:11:43'),(2,2,3,'Para configurar o Java, você precisa baixar o JDK e configurar as variáveis de ambiente.','2024-05-20 22:11:43'),(3,3,4,'Utilize ferramentas como pandas e numpy para análise de dados.','2024-05-20 22:11:43'),(4,4,5,'Estude algoritmos e técnicas de machine learning para criar modelos eficazes.','2024-05-20 22:11:43'),(5,5,6,'Redes neurais são uma parte fundamental da inteligência artificial.','2024-05-20 22:11:43'),(6,6,7,'Front-end lida com o visual do site, enquanto back-end cuida da lógica e banco de dados.','2024-05-20 22:11:43'),(7,7,8,'Para começar no desenvolvimento Android, use o Android Studio.','2024-05-20 22:11:43'),(8,8,9,'A segurança em redes é crucial para proteger dados e informações.','2024-05-20 22:11:43'),(9,9,10,'Arquitetura em nuvem envolve o design de sistemas escaláveis e seguros.','2024-05-20 22:11:43'),(10,10,11,'Automação com DevOps melhora a eficiência e qualidade do software.','2024-05-20 22:11:43'),(11,11,12,'Os princípios de UX focam em criar uma experiência agradável para o usuário.','2024-05-20 22:11:43'),(12,12,13,'SEO é importante para aumentar a visibilidade do seu site.','2024-05-20 22:11:43'),(13,13,14,'A gestão ágil ajuda a lidar com mudanças e melhorar a produtividade.','2024-05-20 22:11:43'),(14,14,15,'Investir requer conhecimento e paciência para alcançar bons resultados.','2024-05-20 22:11:43'),(15,15,16,'A fotografia digital permite a captura e edição de imagens de alta qualidade.','2024-05-20 22:11:43'),(16,16,17,'A composição musical envolve criatividade e conhecimento técnico.','2024-05-20 22:11:43'),(17,17,18,'Aprender novas línguas é uma habilidade valiosa no mundo globalizado.','2024-05-20 22:11:43'),(18,18,19,'Escrita criativa é sobre expressar ideias de forma original e envolvente.','2024-05-20 22:11:43'),(19,19,20,'Um bom logotipo é simples, memorável e representa a marca.','2024-05-20 22:11:43'),(20,20,21,'Gerenciar uma loja virtual envolve estratégias de marketing e atendimento ao cliente.','2024-05-20 22:11:43'),(21,21,22,'Comunicação efetiva é essencial para o sucesso pessoal e profissional.','2024-05-20 22:11:43'),(22,22,23,'Um coach de carreira pode ajudar a alcançar objetivos profissionais.','2024-05-20 22:11:43'),(23,23,24,'O treinamento funcional melhora a força e a flexibilidade.','2024-05-20 22:11:43'),(24,24,25,'A educação infantil é a base para o desenvolvimento futuro das crianças.','2024-05-20 22:11:43'),(25,25,1,'Existem várias ferramentas de e-commerce, como Shopify e WooCommerce.','2024-05-20 22:11:43');
/*!40000 ALTER TABLE `respostas_topicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets_suporte`
--

DROP TABLE IF EXISTS `tickets_suporte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tickets_suporte` (
  `ticket_id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `titulo` varchar(200) NOT NULL,
  `descricao` text,
  `status` enum('Aberto','Em andamento','Fechado') NOT NULL,
  `data_abertura` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_fechamento` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `tickets_suporte_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets_suporte`
--

LOCK TABLES `tickets_suporte` WRITE;
/*!40000 ALTER TABLE `tickets_suporte` DISABLE KEYS */;
INSERT INTO `tickets_suporte` VALUES (1,1,'Problema no acesso ao curso','Não consigo acessar o curso de Java.','Aberto','2024-05-20 22:11:43',NULL),(2,2,'Erro no pagamento','Meu pagamento não foi processado.','Aberto','2024-05-20 22:11:43',NULL),(3,3,'Certificado não emitido','Não recebi meu certificado.','Em andamento','2024-05-20 22:11:43',NULL),(4,4,'Dúvida sobre o curso de Python','Como instalar o Python?','Fechado','2024-05-20 22:11:43',NULL),(5,5,'Vídeo não carrega','O vídeo da aula 3 não carrega.','Aberto','2024-05-20 22:11:43',NULL),(6,6,'Conteúdo desatualizado','O curso de Data Science está desatualizado.','Fechado','2024-05-20 22:11:43',NULL),(7,7,'Problema na emissão de certificado','Certificado com erro.','Em andamento','2024-05-20 22:11:43',NULL),(8,8,'Problemas técnicos','Não consigo acessar meu perfil.','Aberto','2024-05-20 22:11:43',NULL),(9,9,'Dúvida sobre o curso de SEO','Como aplicar técnicas de SEO?','Fechado','2024-05-20 22:11:43',NULL),(10,10,'Erro no certificado','Certificado não foi gerado.','Aberto','2024-05-20 22:11:43',NULL),(11,11,'Problema no vídeo','Vídeo com qualidade ruim.','Aberto','2024-05-20 22:11:43',NULL),(12,12,'Dúvida sobre o curso de Marketing','Como fazer campanhas no Facebook?','Fechado','2024-05-20 22:11:43',NULL),(13,13,'Erro no site','Site não está carregando.','Aberto','2024-05-20 22:11:43',NULL),(14,14,'Problema com o pagamento','Pagamento duplicado.','Fechado','2024-05-20 22:11:43',NULL),(15,15,'Certificado não emitido','Não recebi meu certificado.','Aberto','2024-05-20 22:11:43',NULL),(16,16,'Conteúdo indisponível','Aula 5 não está disponível.','Aberto','2024-05-20 22:11:43',NULL),(17,17,'Problema no login','Não consigo fazer login.','Fechado','2024-05-20 22:11:43',NULL),(18,18,'Erro no curso','Curso com erros de digitação.','Aberto','2024-05-20 22:11:43',NULL),(19,19,'Dúvida sobre o curso de Machine Learning','Como instalar bibliotecas?','Fechado','2024-05-20 22:11:43',NULL),(20,20,'Problema na inscrição','Não consigo me inscrever.','Aberto','2024-05-20 22:11:43',NULL),(21,21,'Erro no pagamento','Pagamento não processado.','Fechado','2024-05-20 22:11:43',NULL),(22,22,'Dúvida sobre o curso de Fotografia','Quais câmeras usar?','Aberto','2024-05-20 22:11:43',NULL),(23,23,'Problema com o vídeo','Vídeo da aula 2 não carrega.','Fechado','2024-05-20 22:11:43',NULL),(24,24,'Erro no acesso ao curso','Não consigo acessar o curso de Python.','Aberto','2024-05-20 22:11:43',NULL),(25,25,'Dúvida sobre o curso de Design','Como usar o Photoshop?','Fechado','2024-05-20 22:11:43',NULL);
/*!40000 ALTER TABLE `tickets_suporte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topicos_forum`
--

DROP TABLE IF EXISTS `topicos_forum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `topicos_forum` (
  `topico_id` int NOT NULL AUTO_INCREMENT,
  `forum_id` int DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  `titulo` varchar(200) NOT NULL,
  `conteudo` text,
  `data_criacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`topico_id`),
  KEY `forum_id` (`forum_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `topicos_forum_ibfk_1` FOREIGN KEY (`forum_id`) REFERENCES `forums` (`forum_id`),
  CONSTRAINT `topicos_forum_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topicos_forum`
--

LOCK TABLES `topicos_forum` WRITE;
/*!40000 ALTER TABLE `topicos_forum` DISABLE KEYS */;
INSERT INTO `topicos_forum` VALUES (1,1,1,'Instalação do Python','Como instalar o Python no Windows?','2024-05-20 22:11:43'),(2,2,2,'Configuração do Java','Dicas para configurar o ambiente Java.','2024-05-20 22:11:43'),(3,3,3,'Análise de Dados','Melhores práticas para análise de dados.','2024-05-20 22:11:43'),(4,4,4,'Modelos de Machine Learning','Como criar modelos eficazes?','2024-05-20 22:11:43'),(5,5,5,'Redes Neurais','Introdução às redes neurais.','2024-05-20 22:11:43'),(6,6,6,'Front-end vs Back-end','Diferenças entre desenvolvimento front-end e back-end.','2024-05-20 22:11:43'),(7,7,7,'Desenvolvimento Android','Primeiros passos no desenvolvimento Android.','2024-05-20 22:11:43'),(8,8,8,'Segurança em Redes','Como garantir a segurança em redes?','2024-05-20 22:11:43'),(9,9,9,'Arquitetura em Nuvem','Princípios de arquitetura em nuvem.','2024-05-20 22:11:43'),(10,10,10,'Automação com DevOps','Ferramentas para automação com DevOps.','2024-05-20 22:11:43'),(11,11,11,'Princípios de UX','Fundamentos do design de experiência do usuário.','2024-05-20 22:11:43'),(12,12,12,'SEO para Iniciantes','Guia básico de SEO.','2024-05-20 22:11:43'),(13,13,13,'Gestão Ágil','Introdução à gestão ágil de projetos.','2024-05-20 22:11:43'),(14,14,14,'Investimentos','Dicas para iniciantes em investimentos.','2024-05-20 22:11:43'),(15,15,15,'Fotografia Digital','Técnicas de fotografia digital.','2024-05-20 22:11:43'),(16,16,16,'Composição Musical','Princípios básicos de composição musical.','2024-05-20 22:11:43'),(17,17,17,'Aprendizado de Línguas','Métodos eficazes para aprender novas línguas.','2024-05-20 22:11:43'),(18,18,18,'Escrita Criativa','Como começar a escrever ficção?','2024-05-20 22:11:43'),(19,19,19,'Design de Logotipos','Dicas para criar logotipos impactantes.','2024-05-20 22:11:43'),(20,20,20,'Loja Virtual','Como criar e gerenciar uma loja virtual.','2024-05-20 22:11:43'),(21,21,21,'Comunicação Efetiva','Importância das habilidades de comunicação.','2024-05-20 22:11:43'),(22,22,22,'Coaching de Carreira','Como escolher um coach de carreira?','2024-05-20 22:11:43'),(23,23,23,'Treinamento Funcional','Benefícios do treinamento funcional.','2024-05-20 22:11:43'),(24,24,24,'Educação de Crianças','Estratégias para educação infantil.','2024-05-20 22:11:43'),(25,25,25,'Ferramentas de E-commerce','Quais são as melhores ferramentas de e-commerce?','2024-05-20 22:11:43');
/*!40000 ALTER TABLE `topicos_forum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `usuario_id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(100) NOT NULL,
  `data_nascimento` date DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `tipo` enum('Aluno','Instrutor','Administrador') NOT NULL,
  PRIMARY KEY (`usuario_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'João Silva','joao.silva@example.com','senha123','1985-01-15','Rua A, 123','111111111','Aluno'),(2,'Maria Oliveira','maria.oliveira@example.com','senha123','1990-05-20','Rua B, 456','222222222','Instrutor'),(3,'Carlos Souza','carlos.souza@example.com','senha123','1982-03-10','Rua C, 789','333333333','Administrador'),(4,'Ana Pereira','ana.pereira@example.com','senha123','1995-02-25','Rua D, 101','444444444','Aluno'),(5,'Paulo Lima','paulo.lima@example.com','senha123','1978-11-05','Rua E, 202','555555555','Instrutor'),(6,'Fernanda Alves','fernanda.alves@example.com','senha123','1988-06-15','Rua F, 303','666666666','Administrador'),(7,'Bruno Costa','bruno.costa@example.com','senha123','1992-09-10','Rua G, 404','777777777','Aluno'),(8,'Carla Rocha','carla.rocha@example.com','senha123','1993-12-25','Rua H, 505','888888888','Instrutor'),(9,'Lucas Ferreira','lucas.ferreira@example.com','senha123','1986-08-30','Rua I, 606','999999999','Administrador'),(10,'Mariana Santos','mariana.santos@example.com','senha123','1991-04-22','Rua J, 707','000000000','Aluno'),(11,'Eduardo Gomes','eduardo.gomes@example.com','senha123','1980-07-13','Rua K, 808','111122222','Instrutor'),(12,'Renata Barros','renata.barros@example.com','senha123','1979-01-31','Rua L, 909','222233333','Administrador'),(13,'Daniel Ribeiro','daniel.ribeiro@example.com','senha123','1994-02-20','Rua M, 1010','333344444','Aluno'),(14,'Aline Martins','aline.martins@example.com','senha123','1987-10-15','Rua N, 1111','444455555','Instrutor'),(15,'Rafael Rodrigues','rafael.rodrigues@example.com','senha123','1983-06-08','Rua O, 1212','555566666','Administrador'),(16,'Camila Castro','camila.castro@example.com','senha123','1985-03-18','Rua P, 1313','666677777','Aluno'),(17,'Marcos Souza','marcos.souza@example.com','senha123','1977-12-05','Rua Q, 1414','777788888','Instrutor'),(18,'Juliana Azevedo','juliana.azevedo@example.com','senha123','1989-08-29','Rua R, 1515','888899999','Administrador'),(19,'Thiago Almeida','thiago.almeida@example.com','senha123','1992-05-23','Rua S, 1616','999900000','Aluno'),(20,'Patricia Mendes','patricia.mendes@example.com','senha123','1981-11-19','Rua T, 1717','000011111','Instrutor'),(21,'Felipe Carvalho','felipe.carvalho@example.com','senha123','1984-04-07','Rua U, 1818','111122223','Administrador'),(22,'Sabrina Lopes','sabrina.lopes@example.com','senha123','1990-09-15','Rua V, 1919','222233334','Aluno'),(23,'André Silva','andre.silva@example.com','senha123','1986-11-01','Rua W, 2020','333344445','Instrutor'),(24,'Gabriela Pinto','gabriela.pinto@example.com','senha123','1983-07-21','Rua X, 2121','444455556','Administrador'),(25,'Leonardo Campos','leonardo.campos@example.com','senha123','1979-12-10','Rua Y, 2222','555566667','Aluno');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `insert_usuarios` AFTER INSERT ON `usuarios` FOR EACH ROW BEGIN
    INSERT INTO log_usuarios (nome, email, senha, data_nascimento, endereco, telefone, tipo, operacao)
    VALUES (NEW.nome, NEW.email, NEW.senha, NEW.data_nascimento, NEW.endereco, NEW.telefone, NEW.tipo, 2);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `update_usuarios` AFTER UPDATE ON `usuarios` FOR EACH ROW BEGIN
    INSERT INTO log_usuarios (nome, email, senha, data_nascimento, endereco, telefone, tipo, operacao)
    VALUES (OLD.nome, OLD.email, OLD.senha, OLD.data_nascimento, OLD.endereco, OLD.telefone, OLD.tipo, 3);
    INSERT INTO log_usuarios (nome, email, senha, data_nascimento, endereco, telefone, tipo, operacao)
    VALUES (NEW.nome, NEW.email, NEW.senha, NEW.data_nascimento, NEW.endereco, NEW.telefone, NEW.tipo,  4);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root1`@`%`*/ /*!50003 TRIGGER `delete_usuarios` BEFORE DELETE ON `usuarios` FOR EACH ROW BEGIN
    INSERT INTO log_usuarios (nome, email, senha, data_nascimento, endereco, telefone, tipo, operacao)
    VALUES (OLD.nome, OLD.email, OLD.senha, OLD.data_nascimento, OLD.endereco, OLD.telefone, OLD.tipo, 1);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Dumping routines for database 'ensinoonlinedb'
--

--
-- Final view structure for view `matriculas_mes_atual`
--

/*!50001 DROP VIEW IF EXISTS `matriculas_mes_atual`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root1`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `matriculas_mes_atual` AS select `matriculas`.`matricula_id` AS `matricula_id`,`matriculas`.`usuario_id` AS `usuario_id`,`matriculas`.`curso_id` AS `curso_id`,`matriculas`.`data_matricula` AS `data_matricula` from `matriculas` where ((year(`matriculas`.`data_matricula`) = year(curdate())) and (month(`matriculas`.`data_matricula`) = month(curdate()))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-20 20:57:37
